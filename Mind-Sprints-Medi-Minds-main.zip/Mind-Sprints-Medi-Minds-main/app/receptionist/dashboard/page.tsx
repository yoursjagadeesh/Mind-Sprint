"use client"

import { useRouter } from "next/navigation"
import { useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { useAppStore } from "@/lib/store"
import { RoleBasedAccess } from "@/components/role-based-access"
import { getTranslation } from "@/lib/translations"
import { Sidebar } from "@/components/layout/sidebar"
import { ThemeToggle } from "@/components/theme-toggle"

export default function ReceptionistDashboard() {
  const router = useRouter()
  const { currentUser, currentLanguage, setCurrentUser } = useAppStore()
  const t = (key: any) => getTranslation(currentLanguage, key)

  useEffect(() => {
    if (!currentUser || currentUser.role !== "receptionist") {
      router.push("/")
    }
  }, [currentUser, router])

  const handleLogout = () => {
    setCurrentUser(null)
    router.push("/")
  }

  const todayAppointments = [
    { id: "1", time: "09:00 AM", patient: "Ramesh Gupta", doctor: "Dr. Sharma", status: "Checked In" },
    { id: "2", time: "10:30 AM", patient: "Sunita Devi", doctor: "Dr. Patel", status: "Waiting" },
    { id: "3", time: "02:00 PM", patient: "Vikram Singh", therapist: "John Therapist", status: "Scheduled" },
  ]

  if (!currentUser) return null

  return (
    <RoleBasedAccess allowedRoles={["receptionist", "admin"]}>
      <Sidebar />
      <div className="min-h-screen bg-gradient-to-br from-background via-primary/5 to-background p-6 ml-64">
        <div className="max-w-7xl mx-auto space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-4xl font-bold gradient-primary-text">Receptionist Dashboard</h1>
              <p className="text-muted-foreground">Welcome, {currentUser?.name}</p>
            </div>
            <div className="flex items-center gap-3">
              <ThemeToggle />
              <Button onClick={handleLogout}>Logout</Button>
            </div>
          </div>

          {/* Quick Stats */}
          <div className="grid md:grid-cols-4 gap-4">
            <Card className="border-blue-500/30 bg-gradient-to-br from-blue-50 to-blue-100 dark:from-blue-950/20 dark:to-blue-900/10">
              <CardContent className="p-6">
                <div className="text-3xl mb-2">📅</div>
                <div className="text-3xl font-bold text-blue-700 dark:text-blue-400">24</div>
                <div className="text-sm text-muted-foreground">Today's Appointments</div>
              </CardContent>
            </Card>
            <Card className="border-green-500/30 bg-gradient-to-br from-green-50 to-green-100 dark:from-green-950/20 dark:to-green-900/10">
              <CardContent className="p-6">
                <div className="text-3xl mb-2">✅</div>
                <div className="text-3xl font-bold text-green-700 dark:text-green-400">18</div>
                <div className="text-sm text-muted-foreground">Checked In</div>
              </CardContent>
            </Card>
            <Card className="border-yellow-500/30 bg-gradient-to-br from-yellow-50 to-yellow-100 dark:from-yellow-950/20 dark:to-yellow-900/10">
              <CardContent className="p-6">
                <div className="text-3xl mb-2">⏳</div>
                <div className="text-3xl font-bold text-yellow-700 dark:text-yellow-400">6</div>
                <div className="text-sm text-muted-foreground">Waiting</div>
              </CardContent>
            </Card>
            <Card className="border-purple-500/30 bg-gradient-to-br from-purple-50 to-purple-100 dark:from-purple-950/20 dark:to-purple-900/10">
              <CardContent className="p-6">
                <div className="text-3xl mb-2">👥</div>
                <div className="text-3xl font-bold text-purple-700 dark:text-purple-400">156</div>
                <div className="text-sm text-muted-foreground">Total Patients</div>
              </CardContent>
            </Card>
          </div>

          {/* Today's Appointments */}
          <Card className="shadow-lg border-primary/20">
            <CardHeader>
              <CardTitle>Today's Appointments</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {todayAppointments.map((apt) => (
                  <div
                    key={apt.id}
                    className="flex items-center justify-between p-4 rounded-lg border bg-card hover:shadow-md transition-all"
                  >
                    <div className="flex items-center gap-4">
                      <div className="text-sm font-mono font-bold">{apt.time}</div>
                      <div>
                        <div className="font-semibold">{apt.patient}</div>
                        <div className="text-sm text-muted-foreground">{apt.doctor || apt.therapist}</div>
                      </div>
                    </div>
                    <span
                      className={`px-3 py-1 rounded-full text-xs font-semibold ${
                        apt.status === "Checked In"
                          ? "bg-green-100 text-green-700 dark:bg-green-950 dark:text-green-400"
                          : apt.status === "Waiting"
                            ? "bg-yellow-100 text-yellow-700 dark:bg-yellow-950 dark:text-yellow-400"
                            : "bg-blue-100 text-blue-700 dark:bg-blue-950 dark:text-blue-400"
                      }`}
                    >
                      {apt.status}
                    </span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </RoleBasedAccess>
  )
}
