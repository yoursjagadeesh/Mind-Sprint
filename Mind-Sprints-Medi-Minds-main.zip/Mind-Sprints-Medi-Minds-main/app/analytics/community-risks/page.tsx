"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { useAppStore } from "@/lib/store"
import { RoleBasedAccess } from "@/components/role-based-access"
import { getTranslation } from "@/lib/translations"
import { Sidebar } from "@/components/layout/sidebar"
import { ThemeToggle } from "@/components/theme-toggle"

export default function CommunityRisksPage() {
  const router = useRouter()
  const { currentLanguage } = useAppStore()
  const [selectedRegion, setSelectedRegion] = useState("all")
  const [timeframe, setTimeframe] = useState("current")

  const t = (key: any) => getTranslation(currentLanguage, key)

  // Mock community health data
  const communityRisks = [
    {
      id: "1",
      condition: "Seasonal Allergies",
      severity: "High",
      affectedPopulation: 245,
      trend: "Rising",
      region: "Urban",
      prediction: "Expected to peak in next 2 weeks",
      factors: ["High pollen count", "Air quality index deteriorating", "Humidity rise"],
    },
    {
      id: "2",
      condition: "Digestive Disorders",
      severity: "Moderate",
      affectedPopulation: 189,
      trend: "Stable",
      region: "Rural",
      prediction: "Likely to remain stable",
      factors: ["Dietary patterns", "Water quality", "Seasonal changes"],
    },
    {
      id: "3",
      condition: "Joint Pain & Arthritis",
      severity: "Moderate",
      affectedPopulation: 312,
      trend: "Rising",
      region: "All",
      prediction: "Increase expected due to monsoon",
      factors: ["Weather changes", "Humidity", "Temperature drop"],
    },
    {
      id: "4",
      condition: "Respiratory Issues",
      severity: "Low",
      affectedPopulation: 87,
      trend: "Declining",
      region: "Urban",
      prediction: "Expected to improve",
      factors: ["Better air quality", "Treatment effectiveness"],
    },
  ]

  const seasonalInsights = {
    currentSeason: "Summer",
    dominantDosha: "Pitta",
    riskLevel: "Moderate to High",
    recommendations: [
      "Increase cooling therapies in treatment plans",
      "Recommend dietary modifications to reduce heat",
      "Stock up on Pitta-balancing herbs",
      "Plan outdoor therapy sessions for early morning",
    ],
  }

  return (
    <RoleBasedAccess allowedRoles={["doctor", "admin"]}>
      <Sidebar />
      <div className="min-h-screen bg-gradient-to-br from-background via-secondary/5 to-background p-6 ml-64">
        <div className="max-w-7xl mx-auto space-y-6">
          {/* Header */}
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-4xl font-bold gradient-primary-text">Community Health Risk Prediction</h1>
              <p className="text-muted-foreground mt-2">
                Population-level analytics for proactive healthcare resource planning
              </p>
            </div>
            <div className="flex items-center gap-3">
              <ThemeToggle />
              <Button variant="outline" onClick={() => router.back()}>
                ← Back
              </Button>
            </div>
          </div>

          {/* Seasonal Insights */}
          <Card className="border-orange-500/30 bg-gradient-to-br from-orange-50 to-yellow-50 dark:from-orange-950/20 dark:to-yellow-950/10 shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <span className="text-2xl">🌞</span>
                Seasonal Health Insights - {seasonalInsights.currentSeason}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid md:grid-cols-3 gap-4">
                <div>
                  <div className="text-sm text-muted-foreground">Dominant Dosha</div>
                  <div className="text-xl font-bold text-orange-700 dark:text-orange-400">
                    {seasonalInsights.dominantDosha}
                  </div>
                </div>
                <div>
                  <div className="text-sm text-muted-foreground">Community Risk Level</div>
                  <div className="text-xl font-bold text-orange-700 dark:text-orange-400">
                    {seasonalInsights.riskLevel}
                  </div>
                </div>
                <div>
                  <div className="text-sm text-muted-foreground">Total Affected</div>
                  <div className="text-xl font-bold text-orange-700 dark:text-orange-400">833 Patients</div>
                </div>
              </div>
              <div>
                <div className="text-sm font-semibold mb-2">Strategic Recommendations:</div>
                <ul className="space-y-1">
                  {seasonalInsights.recommendations.map((rec, i) => (
                    <li key={i} className="text-sm flex items-start gap-2">
                      <span className="text-green-600 dark:text-green-400">✓</span>
                      <span>{rec}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </CardContent>
          </Card>

          {/* Filters */}
          <Card className="border-primary/20">
            <CardContent className="pt-6">
              <div className="grid md:grid-cols-3 gap-4">
                <div>
                  <label className="text-sm font-semibold mb-2 block">Region</label>
                  <select
                    value={selectedRegion}
                    onChange={(e) => setSelectedRegion(e.target.value)}
                    className="w-full px-4 py-2 rounded-lg border bg-background"
                  >
                    <option value="all">All Regions</option>
                    <option value="urban">Urban</option>
                    <option value="rural">Rural</option>
                    <option value="suburban">Suburban</option>
                  </select>
                </div>
                <div>
                  <label className="text-sm font-semibold mb-2 block">Timeframe</label>
                  <select
                    value={timeframe}
                    onChange={(e) => setTimeframe(e.target.value)}
                    className="w-full px-4 py-2 rounded-lg border bg-background"
                  >
                    <option value="current">Current Week</option>
                    <option value="forecast">2-Week Forecast</option>
                    <option value="monthly">Monthly Trend</option>
                  </select>
                </div>
                <div className="flex items-end">
                  <Button className="w-full bg-gradient-to-r from-primary to-secondary">Generate AI Prediction</Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Risk Cards */}
          <div className="grid gap-4">
            {communityRisks
              .filter((risk) => selectedRegion === "all" || risk.region.toLowerCase() === selectedRegion)
              .map((risk) => (
                <Card
                  key={risk.id}
                  className={`border-2 shadow-lg ${
                    risk.severity === "High"
                      ? "border-red-500/50 bg-red-50/30 dark:bg-red-950/10"
                      : risk.severity === "Moderate"
                        ? "border-yellow-500/50 bg-yellow-50/30 dark:bg-yellow-950/10"
                        : "border-green-500/50 bg-green-50/30 dark:bg-green-950/10"
                  }`}
                >
                  <CardContent className="p-6">
                    <div className="grid md:grid-cols-5 gap-4">
                      <div className="md:col-span-2">
                        <div className="flex items-start justify-between mb-2">
                          <div>
                            <div className="text-xl font-bold">{risk.condition}</div>
                            <div className="text-sm text-muted-foreground">{risk.region} Region</div>
                          </div>
                          <span
                            className={`px-3 py-1 rounded-full text-xs font-bold ${
                              risk.severity === "High"
                                ? "bg-red-500 text-white"
                                : risk.severity === "Moderate"
                                  ? "bg-yellow-500 text-white"
                                  : "bg-green-500 text-white"
                            }`}
                          >
                            {risk.severity}
                          </span>
                        </div>
                        <div className="text-sm mt-3">
                          <span className="text-muted-foreground">Affected Population:</span>
                          <span className="font-bold ml-2 text-lg">{risk.affectedPopulation}</span>
                        </div>
                      </div>
                      <div>
                        <div className="text-sm text-muted-foreground mb-1">Trend</div>
                        <div
                          className={`font-bold ${
                            risk.trend === "Rising"
                              ? "text-red-600"
                              : risk.trend === "Declining"
                                ? "text-green-600"
                                : "text-yellow-600"
                          }`}
                        >
                          {risk.trend === "Rising" ? "↑" : risk.trend === "Declining" ? "↓" : "→"} {risk.trend}
                        </div>
                      </div>
                      <div className="md:col-span-2">
                        <div className="text-sm text-muted-foreground mb-1">Contributing Factors</div>
                        <div className="flex flex-wrap gap-1">
                          {risk.factors.map((factor, i) => (
                            <span
                              key={i}
                              className="text-xs px-2 py-1 bg-primary/10 rounded-full border border-primary/20"
                            >
                              {factor}
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>
                    <div className="mt-4 pt-4 border-t border-border">
                      <div className="text-sm font-semibold text-primary">AI Forecast:</div>
                      <div className="text-sm text-muted-foreground mt-1">{risk.prediction}</div>
                    </div>
                  </CardContent>
                </Card>
              ))}
          </div>

          {/* Environmental Factors */}
          <Card className="border-primary/20 shadow-lg">
            <CardHeader>
              <CardTitle>Environmental Health Factors</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-4 gap-4">
                <div className="p-4 rounded-lg bg-blue-50 dark:bg-blue-950/20 border border-blue-200 dark:border-blue-800">
                  <div className="text-sm text-muted-foreground">Temperature</div>
                  <div className="text-2xl font-bold">35°C</div>
                  <div className="text-xs text-red-600">↑ Above normal</div>
                </div>
                <div className="p-4 rounded-lg bg-green-50 dark:bg-green-950/20 border border-green-200 dark:border-green-800">
                  <div className="text-sm text-muted-foreground">Humidity</div>
                  <div className="text-2xl font-bold">68%</div>
                  <div className="text-xs text-green-600">→ Normal</div>
                </div>
                <div className="p-4 rounded-lg bg-orange-50 dark:bg-orange-950/20 border border-orange-200 dark:border-orange-800">
                  <div className="text-sm text-muted-foreground">Air Quality</div>
                  <div className="text-2xl font-bold">156</div>
                  <div className="text-xs text-orange-600">⚠ Moderate</div>
                </div>
                <div className="p-4 rounded-lg bg-purple-50 dark:bg-purple-950/20 border border-purple-200 dark:border-purple-800">
                  <div className="text-sm text-muted-foreground">Pollen Count</div>
                  <div className="text-2xl font-bold">High</div>
                  <div className="text-xs text-red-600">↑ Peak season</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </RoleBasedAccess>
  )
}
