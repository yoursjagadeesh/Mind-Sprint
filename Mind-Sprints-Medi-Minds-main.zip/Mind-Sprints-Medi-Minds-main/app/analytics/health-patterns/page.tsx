"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { useAppStore } from "@/lib/store"
import { RoleBasedAccess } from "@/components/role-based-access"
import { getTranslation } from "@/lib/translations"
import { Sidebar } from "@/components/layout/sidebar"
import { ThemeToggle } from "@/components/theme-toggle"

export default function HealthPatternsPage() {
  const router = useRouter()
  const { currentUser, currentLanguage } = useAppStore()
  const [selectedPatient, setSelectedPatient] = useState("")
  const [timeRange, setTimeRange] = useState("3months")

  const t = (key: any) => getTranslation(currentLanguage, key)

  const healthPatterns = [
    {
      id: "1",
      patientName: "Rajesh Kumar",
      doshaImbalance: "Pitta elevated by 35%",
      trend: "Worsening",
      riskScore: 72,
      lastVisit: "2024-01-05",
      symptoms: ["Acidity", "Skin irritation", "Sleep issues"],
      recommendation: "Cooling therapies, dietary changes needed",
    },
    {
      id: "2",
      patientName: "Priya Sharma",
      doshaImbalance: "Vata imbalance detected",
      trend: "Improving",
      riskScore: 45,
      lastVisit: "2024-01-10",
      symptoms: ["Joint pain", "Anxiety", "Dry skin"],
      recommendation: "Continue current treatment plan",
    },
    {
      id: "3",
      patientName: "Amit Patel",
      doshaImbalance: "Kapha excess",
      trend: "Stable",
      riskScore: 58,
      lastVisit: "2024-01-08",
      symptoms: ["Weight gain", "Lethargy", "Congestion"],
      recommendation: "Increase physical activity, detox therapy",
    },
  ]

  const doshaStats = {
    pitta: 35,
    vata: 42,
    kapha: 28,
  }

  return (
    <RoleBasedAccess allowedRoles={["doctor", "admin"]}>
      <Sidebar />
      <div className="min-h-screen bg-gradient-to-br from-background via-primary/5 to-background p-6 ml-64">
        <div className="max-w-7xl mx-auto space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-4xl font-bold gradient-primary-text">Chronic Care Health Pattern Analysis</h1>
              <p className="text-muted-foreground mt-2">
                AI-powered long-term health trend monitoring for Ayurvedic treatments
              </p>
            </div>
            <div className="flex items-center gap-3">
              <ThemeToggle />
              <Button variant="outline" onClick={() => router.back()}>
                ← Back
              </Button>
            </div>
          </div>

          <Card className="border-primary/20 shadow-lg">
            <CardHeader>
              <CardTitle>Community Dosha Distribution</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-3 gap-4">
                <div className="p-6 rounded-xl bg-gradient-to-br from-red-50 to-red-100 dark:from-red-950/30 dark:to-red-900/20 border border-red-200 dark:border-red-800">
                  <div className="text-3xl mb-2">🔥</div>
                  <div className="text-2xl font-bold text-red-700 dark:text-red-400">{doshaStats.pitta}%</div>
                  <div className="text-sm text-red-600 dark:text-red-500">Pitta Imbalance</div>
                </div>
                <div className="p-6 rounded-xl bg-gradient-to-br from-blue-50 to-blue-100 dark:from-blue-950/30 dark:to-blue-900/20 border border-blue-200 dark:border-blue-800">
                  <div className="text-3xl mb-2">💨</div>
                  <div className="text-2xl font-bold text-blue-700 dark:text-blue-400">{doshaStats.vata}%</div>
                  <div className="text-sm text-blue-600 dark:text-blue-500">Vata Imbalance</div>
                </div>
                <div className="p-6 rounded-xl bg-gradient-to-br from-green-50 to-green-100 dark:from-green-950/30 dark:to-green-900/20 border border-green-200 dark:border-green-800">
                  <div className="text-3xl mb-2">🌊</div>
                  <div className="text-2xl font-bold text-green-700 dark:text-green-400">{doshaStats.kapha}%</div>
                  <div className="text-sm text-green-600 dark:text-green-500">Kapha Imbalance</div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-primary/20">
            <CardContent className="pt-6">
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-semibold mb-2 block">Time Range</label>
                  <select
                    value={timeRange}
                    onChange={(e) => setTimeRange(e.target.value)}
                    className="w-full px-4 py-2 rounded-lg border bg-background"
                  >
                    <option value="1month">Last 1 Month</option>
                    <option value="3months">Last 3 Months</option>
                    <option value="6months">Last 6 Months</option>
                    <option value="1year">Last 1 Year</option>
                  </select>
                </div>
                <div>
                  <label className="text-sm font-semibold mb-2 block">Filter by Patient</label>
                  <select
                    value={selectedPatient}
                    onChange={(e) => setSelectedPatient(e.target.value)}
                    className="w-full px-4 py-2 rounded-lg border bg-background"
                  >
                    <option value="">All Patients</option>
                    {healthPatterns.map((p) => (
                      <option key={p.id} value={p.id}>
                        {p.patientName}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="grid gap-4">
            {healthPatterns
              .filter((p) => !selectedPatient || p.id === selectedPatient)
              .map((pattern) => (
                <Card
                  key={pattern.id}
                  className={`border-2 ${
                    pattern.trend === "Worsening"
                      ? "border-red-500/50 bg-red-50/50 dark:bg-red-950/20"
                      : pattern.trend === "Improving"
                        ? "border-green-500/50 bg-green-50/50 dark:bg-green-950/20"
                        : "border-yellow-500/50 bg-yellow-50/50 dark:bg-yellow-950/20"
                  } shadow-lg`}
                >
                  <CardContent className="p-6">
                    <div className="grid md:grid-cols-4 gap-4">
                      <div>
                        <div className="text-sm text-muted-foreground mb-1">Patient</div>
                        <div className="font-bold text-lg">{pattern.patientName}</div>
                        <div className="text-xs text-muted-foreground">Last visit: {pattern.lastVisit}</div>
                      </div>
                      <div>
                        <div className="text-sm text-muted-foreground mb-1">Dosha Status</div>
                        <div className="font-semibold">{pattern.doshaImbalance}</div>
                        <div
                          className={`text-sm font-bold mt-1 ${
                            pattern.trend === "Worsening"
                              ? "text-red-600"
                              : pattern.trend === "Improving"
                                ? "text-green-600"
                                : "text-yellow-600"
                          }`}
                        >
                          {pattern.trend === "Worsening" ? "↓" : pattern.trend === "Improving" ? "↑" : "→"}{" "}
                          {pattern.trend}
                        </div>
                      </div>
                      <div>
                        <div className="text-sm text-muted-foreground mb-1">Wellness Score</div>
                        <div className="flex items-center gap-2">
                          <div className="text-2xl font-bold">{pattern.riskScore}</div>
                          <div className="text-xs text-muted-foreground">/100</div>
                        </div>
                        <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2 mt-2">
                          <div
                            className={`h-2 rounded-full ${
                              pattern.riskScore > 70
                                ? "bg-red-500"
                                : pattern.riskScore > 50
                                  ? "bg-yellow-500"
                                  : "bg-green-500"
                            }`}
                            style={{ width: `${pattern.riskScore}%` }}
                          />
                        </div>
                      </div>
                      <div>
                        <div className="text-sm text-muted-foreground mb-1">Symptoms</div>
                        <div className="flex flex-wrap gap-1">
                          {pattern.symptoms.map((symptom, i) => (
                            <span
                              key={i}
                              className="text-xs px-2 py-1 bg-primary/10 rounded-full border border-primary/20"
                            >
                              {symptom}
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>
                    <div className="mt-4 pt-4 border-t border-border">
                      <div className="text-sm font-semibold text-primary">AI Recommendation:</div>
                      <div className="text-sm text-muted-foreground mt-1">{pattern.recommendation}</div>
                    </div>
                  </CardContent>
                </Card>
              ))}
          </div>
        </div>
      </div>
    </RoleBasedAccess>
  )
}
