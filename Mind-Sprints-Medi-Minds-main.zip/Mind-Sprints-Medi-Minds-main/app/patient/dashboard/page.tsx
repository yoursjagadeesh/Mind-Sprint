"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { useAppStore } from "@/lib/store"
import { NotificationCenter } from "@/components/notifications/notification-center"
import { AIChatbot } from "@/components/chatbot/ai-chatbot"
import { PatientRegistrationForm } from "@/components/patient/registration-form"
import { ConsultationBookingForm } from "@/components/consultation/booking-form"
import { TherapyScheduler } from "@/components/therapy/scheduler"
import { Sidebar } from "@/components/layout/sidebar"
import { ThemeToggle } from "@/components/theme-toggle"
import { ConsultationDetailsDialog } from "@/components/consultation/consultation-details-dialog"
import { TherapyDetailsDialog } from "@/components/therapy/therapy-details-dialog"
import { PrescriptionDetailsDialog } from "@/components/prescription/prescription-details-dialog"
import type { Consultation, TherapySession, Prescription } from "@/lib/types"

export default function PatientDashboard() {
  const router = useRouter()
  const { currentUser, consultations, therapySessions, prescriptions, setCurrentUser } = useAppStore()

  const [selectedConsultation, setSelectedConsultation] = useState<Consultation | null>(null)
  const [selectedTherapy, setSelectedTherapy] = useState<TherapySession | null>(null)
  const [selectedPrescription, setSelectedPrescription] = useState<Prescription | null>(null)
  const [consultationDialogOpen, setConsultationDialogOpen] = useState(false)
  const [therapyDialogOpen, setTherapyDialogOpen] = useState(false)
  const [prescriptionDialogOpen, setPrescriptionDialogOpen] = useState(false)

  useEffect(() => {
    if (!currentUser || currentUser.role !== "patient") {
      router.push("/")
    }
  }, [currentUser, router])

  const handleLogout = () => {
    setCurrentUser(null)
    router.push("/")
  }

  const handleConsultationClick = (consultation: Consultation) => {
    setSelectedConsultation(consultation)
    setConsultationDialogOpen(true)
  }

  const handleTherapyClick = (session: TherapySession) => {
    setSelectedTherapy(session)
    setTherapyDialogOpen(true)
  }

  const handlePrescriptionClick = (prescription: Prescription) => {
    setSelectedPrescription(prescription)
    setPrescriptionDialogOpen(true)
  }

  if (!currentUser) return null

  return (
    <>
      <Sidebar />
      <main className="min-h-screen bg-gradient-to-br from-background via-primary/2 to-background ml-64">
        <header className="border-b border-border/50 bg-gradient-to-r from-card to-card/50 backdrop-blur-sm sticky top-0 z-40 animate-slide-down shadow-lg">
          <div className="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-primary to-secondary rounded-xl flex items-center justify-center shadow-md">
                <span className="text-xl">⚕️</span>
              </div>
              <div>
                <h1 className="text-2xl font-bold gradient-primary-text">Smart Healthcare</h1>
                <p className="text-xs text-muted-foreground">Patient Dashboard</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <ThemeToggle />
              <NotificationCenter />
              <Button
                variant="outline"
                onClick={handleLogout}
                className="border-primary/30 hover:bg-primary/5 font-semibold bg-transparent"
              >
                Logout
              </Button>
            </div>
          </div>
        </header>

        <div className="max-w-7xl mx-auto px-4 py-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
            {[
              { label: "Consultations", value: consultations.length, icon: "👨‍⚕️", color: "from-blue-500 to-blue-600" },
              {
                label: "Therapy Sessions",
                value: therapySessions.length,
                icon: "🧘",
                color: "from-green-500 to-green-600",
              },
              {
                label: "Prescriptions",
                value: prescriptions.length,
                icon: "💊",
                color: "from-purple-500 to-purple-600",
              },
              { label: "Health Score", value: "85%", icon: "❤️", color: "from-red-500 to-red-600" },
            ].map((stat, i) => (
              <Card
                key={stat.label}
                className="border-0 shadow-lg hover:shadow-xl transition-all hover:-translate-y-1 bg-gradient-to-br from-card to-card/50 animate-in"
                style={{ animationDelay: `${i * 50}ms` }}
              >
                <CardContent className="pt-6">
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="text-3xl font-bold gradient-primary-text">{stat.value}</div>
                      <div className="text-sm text-muted-foreground mt-1">{stat.label}</div>
                    </div>
                    <div className={`text-3xl p-3 rounded-lg bg-gradient-to-br ${stat.color} bg-opacity-20`}>
                      {stat.icon}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
            <div className="lg:col-span-2 space-y-6">
              <PatientRegistrationForm />
              <ConsultationBookingForm />
              <TherapyScheduler />
            </div>

            <div className="space-y-6">
              <Card className="border-primary/20 shadow-lg hover:shadow-xl transition-all animate-in overflow-hidden">
                <div className="h-1 bg-gradient-to-r from-primary to-secondary" />
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <span className="text-2xl">👨‍⚕️</span>Upcoming Consultations
                  </CardTitle>
                  <CardDescription>Your scheduled appointments</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {consultations.filter((c) => c.status === "scheduled").length === 0 ? (
                      <p className="text-sm text-muted-foreground py-4 text-center">No scheduled consultations</p>
                    ) : (
                      consultations
                        .filter((c) => c.status === "scheduled")
                        .map((consultation) => (
                          <div
                            key={consultation.id}
                            onClick={() => handleConsultationClick(consultation)}
                            className="p-4 bg-gradient-to-br from-blue-50 to-blue-50/50 dark:from-blue-950/20 dark:to-blue-950/10 rounded-lg border border-blue-200/30 dark:border-blue-800/30 hover:shadow-md transition-all cursor-pointer hover:scale-105"
                          >
                            <p className="font-semibold text-sm text-foreground">
                              📅 {consultation.date.toLocaleDateString()}
                            </p>
                            <p className="text-xs text-muted-foreground">🕐 {consultation.time}</p>
                            <p className="text-xs mt-2 text-foreground">{consultation.symptoms.substring(0, 50)}...</p>
                            <p className="text-xs mt-1 text-primary font-medium">Click for details →</p>
                          </div>
                        ))
                    )}
                  </div>
                </CardContent>
              </Card>

              <Card className="border-primary/20 shadow-lg hover:shadow-xl transition-all animate-in overflow-hidden">
                <div className="h-1 bg-gradient-to-r from-green-500 to-emerald-500" />
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <span className="text-2xl">🧘</span>Therapy Sessions
                  </CardTitle>
                  <CardDescription>Scheduled sessions</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {therapySessions.filter((t) => t.status === "scheduled").length === 0 ? (
                      <p className="text-sm text-muted-foreground py-4 text-center">No scheduled sessions</p>
                    ) : (
                      therapySessions
                        .filter((t) => t.status === "scheduled")
                        .map((session) => (
                          <div
                            key={session.id}
                            onClick={() => handleTherapyClick(session)}
                            className="p-4 bg-gradient-to-br from-green-50 to-green-50/50 dark:from-green-950/20 dark:to-green-950/10 rounded-lg border border-green-200/30 dark:border-green-800/30 hover:shadow-md transition-all cursor-pointer hover:scale-105"
                          >
                            <p className="font-semibold text-sm text-foreground">
                              📅 {session.date.toLocaleDateString()}
                            </p>
                            <p className="text-xs text-muted-foreground">
                              🕐 {session.startTime} - {session.endTime}
                            </p>
                            <p className="text-xs mt-1 text-green-600 dark:text-green-400 font-medium">
                              Click for details →
                            </p>
                          </div>
                        ))
                    )}
                  </div>
                </CardContent>
              </Card>

              <Card className="border-primary/20 shadow-lg hover:shadow-xl transition-all animate-in overflow-hidden">
                <div className="h-1 bg-gradient-to-r from-purple-500 to-pink-500" />
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <span className="text-2xl">💊</span>Recent Prescriptions
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {prescriptions.length === 0 ? (
                      <p className="text-sm text-muted-foreground py-4 text-center">No prescriptions yet</p>
                    ) : (
                      prescriptions.slice(0, 3).map((prescription) => (
                        <div
                          key={prescription.id}
                          onClick={() => handlePrescriptionClick(prescription)}
                          className="p-4 bg-gradient-to-br from-purple-50 to-purple-50/50 dark:from-purple-950/20 dark:to-purple-950/10 rounded-lg border border-purple-200/30 dark:border-purple-800/30 hover:shadow-md transition-all cursor-pointer hover:scale-105"
                        >
                          <p className="font-semibold text-sm text-foreground">{prescription.diagnoses[0]}</p>
                          <p className="text-xs text-muted-foreground">
                            📅 {new Date(prescription.createdAt).toLocaleDateString()}
                          </p>
                          <p className="text-xs mt-2 text-foreground">
                            💊 {prescription.medications.length} medications
                          </p>
                          <p className="text-xs mt-1 text-purple-600 dark:text-purple-400 font-medium">
                            Click for details →
                          </p>
                        </div>
                      ))
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>

        <AIChatbot />
      </main>
      <ConsultationDetailsDialog
        open={consultationDialogOpen}
        onOpenChange={setConsultationDialogOpen}
        consultation={selectedConsultation}
      />
      <TherapyDetailsDialog open={therapyDialogOpen} onOpenChange={setTherapyDialogOpen} session={selectedTherapy} />
      <PrescriptionDetailsDialog
        open={prescriptionDialogOpen}
        onOpenChange={setPrescriptionDialogOpen}
        prescription={selectedPrescription}
      />
    </>
  )
}
