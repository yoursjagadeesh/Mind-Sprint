"use client"

import { useEffect } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { useAppStore } from "@/lib/store"
import { Sidebar } from "@/components/layout/sidebar"
import { ThemeToggle } from "@/components/theme-toggle"
import { FileText, Download } from "lucide-react"

export default function ReportsPage() {
  const router = useRouter()
  const { currentUser, consultations, prescriptions, therapySessions } = useAppStore()

  useEffect(() => {
    if (!currentUser) {
      router.push("/")
    }
  }, [currentUser, router])

  if (!currentUser) return null

  const handleDownloadReport = (reportType: string) => {
    let reportContent = ""
    let reportData = []

    if (reportType === "consultations") {
      reportData = consultations
      reportContent = `CONSULTATION SUMMARY REPORT
Generated: ${new Date().toLocaleDateString()}
Total Consultations: ${consultations.length}

${consultations
  .map(
    (c, idx) => `
${idx + 1}. Consultation ID: ${c.id}
   Date: ${c.date.toLocaleDateString()} at ${c.time}
   Doctor ID: ${c.doctorId}
   Status: ${c.status}
   Symptoms: ${c.symptoms}
   Notes: ${c.notes || "N/A"}
`,
  )
  .join("\n")}
`
    } else if (reportType === "prescriptions") {
      reportData = prescriptions
      reportContent = `PRESCRIPTION RECORDS REPORT
Generated: ${new Date().toLocaleDateString()}
Total Prescriptions: ${prescriptions.length}

${prescriptions
  .map(
    (p, idx) => `
${idx + 1}. Prescription ID: ${p.id}
   Date: ${new Date(p.createdAt).toLocaleDateString()}
   Doctor ID: ${p.doctorId}
   Diagnoses: ${p.diagnoses.join(", ")}
   Medications: ${p.medications.map((m) => `${m.name} (${m.dosage})`).join(", ")}
   Instructions: ${p.instructions}
`,
  )
  .join("\n")}
`
    } else if (reportType === "therapy") {
      reportData = therapySessions
      reportContent = `THERAPY SESSIONS REPORT
Generated: ${new Date().toLocaleDateString()}
Total Sessions: ${therapySessions.length}

${therapySessions
  .map(
    (t, idx) => `
${idx + 1}. Session ID: ${t.id}
   Date: ${t.date.toLocaleDateString()}
   Time: ${t.startTime} - ${t.endTime}
   Therapist ID: ${t.therapistId}
   Room ID: ${t.roomId}
   Status: ${t.status}
   Notes: ${t.notes || "N/A"}
`,
  )
  .join("\n")}
`
    }

    // Create and download the file
    const blob = new Blob([reportContent], { type: "text/plain" })
    const url = window.URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `${reportType}_report_${new Date().toISOString().split("T")[0]}.txt`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    window.URL.revokeObjectURL(url)
  }

  const reports = [
    {
      id: "1",
      type: "consultations",
      title: "Consultation Summary",
      description: "Complete history of all consultations",
      count: consultations.length,
      date: new Date().toLocaleDateString(),
    },
    {
      id: "2",
      type: "prescriptions",
      title: "Prescription Records",
      description: "All prescribed medications and treatments",
      count: prescriptions.length,
      date: new Date().toLocaleDateString(),
    },
    {
      id: "3",
      type: "therapy",
      title: "Therapy Sessions Report",
      description: "Detailed therapy session history",
      count: therapySessions.length,
      date: new Date().toLocaleDateString(),
    },
  ]

  return (
    <>
      <Sidebar />
      <main className="min-h-screen bg-background ml-64">
        <header className="border-b border-border bg-card sticky top-0 z-40">
          <div className="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
            <h1 className="text-2xl font-bold">Medical Reports</h1>
            <div className="flex items-center gap-4">
              <ThemeToggle />
              <Button variant="outline" onClick={() => router.back()}>
                Back
              </Button>
            </div>
          </div>
        </header>

        <div className="max-w-7xl mx-auto px-4 py-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {reports.map((report) => (
              <Card key={report.id} className="hover:shadow-lg transition-all">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <FileText className="h-8 w-8 text-primary" />
                    <span className="text-2xl font-bold text-primary">{report.count}</span>
                  </div>
                  <CardTitle className="mt-4">{report.title}</CardTitle>
                  <CardDescription>{report.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground mb-4">Last updated: {report.date}</p>
                  <Button
                    className="w-full bg-primary hover:bg-primary/90 text-primary-foreground"
                    onClick={() => handleDownloadReport(report.type)}
                  >
                    <Download className="h-4 w-4 mr-2" />
                    Download Report
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </main>
    </>
  )
}
