"use client"

import type React from "react"

import { useRouter } from "next/navigation"
import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { useAppStore } from "@/lib/store"
import { getTranslation } from "@/lib/translations"
import type { Language } from "@/lib/types"

export default function Home() {
  const router = useRouter()
  const { currentUser, currentLanguage, setLanguage } = useAppStore()
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  useEffect(() => {
    if (currentUser) {
      if (currentUser.role === "doctor") {
        router.push("/doctor/dashboard")
      } else if (currentUser.role === "therapist") {
        router.push("/therapist/dashboard")
      } else if (currentUser.role === "admin") {
        router.push("/admin/dashboard")
      } else {
        router.push("/patient/dashboard")
      }
    }
  }, [currentUser, router])

  const t = (key: any) => getTranslation(currentLanguage, key)

  // Language Selector - Top Right using native HTML select
  const handleLanguageChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setLanguage(e.target.value as Language)
  }

  if (!mounted) return null

  return (
    <main className="min-h-screen bg-gradient-to-br from-background via-primary/5 to-background animate-fade-in">
      {/* Language Selector - Top Right using native HTML select */}
      <div className="absolute top-6 right-6 z-50">
        <div className="flex items-center gap-2 bg-card/95 backdrop-blur-sm px-4 py-2 rounded-xl border border-primary/20 shadow-lg">
          <span className="text-sm font-semibold text-muted-foreground">🌐</span>
          <select
            value={currentLanguage}
            onChange={handleLanguageChange}
            className="bg-transparent border-none outline-none text-sm font-medium cursor-pointer text-foreground px-2 py-1 rounded focus:ring-2 focus:ring-primary/50"
            style={{ minWidth: "120px" }}
          >
            <option value="en">🇬🇧 English</option>
            <option value="hi">🇮🇳 हिन्दी</option>
            <option value="te">🇮🇳 తెలుగు</option>
            <option value="ta">🇮🇳 தமிழ்</option>
            <option value="kn">🇮🇳 ಕನ್ನಡ</option>
            <option value="bn">🇮🇳 বাঙ্গালী</option>
            <option value="mr">🇮🇳 मराठी</option>
            <option value="gu">🇮🇳 ગુજરાતી</option>
            <option value="pa">🇮🇳 ਪੰਜਾਬੀ</option>
            <option value="es">🇪🇸 Español</option>
            <option value="fr">🇫🇷 Français</option>
            <option value="pt">🇵🇹 Português</option>
          </select>
        </div>
      </div>

      {/* Hero Section */}
      <div className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-secondary/5 to-transparent pointer-events-none" />

        <div className="relative max-w-7xl mx-auto px-4 py-20 md:py-32">
          <div className="text-center space-y-8 animate-in">
            {/* Logo */}
            <div className="flex justify-center">
              <div className="w-20 h-20 bg-gradient-to-br from-primary to-secondary rounded-3xl flex items-center justify-center shadow-lg">
                <span className="text-5xl font-bold text-primary-foreground">⚕️</span>
              </div>
            </div>

            {/* Title */}
            <div className="space-y-4">
              <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold gradient-primary-text">{t("appTitle")}</h1>
              <p className="text-xl md:text-2xl text-muted-foreground max-w-2xl mx-auto leading-relaxed">
                {t("appSubtitle")}
              </p>
            </div>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center pt-4">
              <Button
                onClick={() => router.push("/login")}
                className="px-8 py-6 bg-gradient-to-r from-primary to-secondary hover:shadow-lg text-primary-foreground text-lg rounded-xl font-semibold shadow-lg transition-all animate-scale-in"
              >
                {t("getStarted")}
              </Button>
              <Button
                variant="outline"
                className="px-8 py-6 border-2 border-primary text-primary hover:bg-primary/5 text-lg rounded-xl font-semibold transition-all bg-transparent"
                onClick={() => router.push("/login")}
              >
                {t("signIn")}
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <section className="relative py-20 md:py-32 bg-gradient-to-b from-transparent to-primary/5">
        <div className="max-w-7xl mx-auto px-4">
          <h2 className="text-4xl md:text-5xl font-bold text-center mb-4 gradient-primary-text">{t("ourServices")}</h2>
          <p className="text-center text-muted-foreground text-lg mb-16 max-w-2xl mx-auto">
            {t("comprehensiveServices")}
          </p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                icon: "🏥",
                title: t("doctorConsultation"),
                description: t("doctorConsultationDescription"),
                color: "from-blue-500",
              },
              {
                icon: "💊",
                title: t("digitalPrescriptions"),
                description: t("digitalPrescriptionsDescription"),
                color: "from-green-500",
              },
              {
                icon: "🧘",
                title: t("therapyScheduling"),
                description: t("therapySchedulingDescription"),
                color: "from-purple-500",
              },
            ].map((service, i) => (
              <div
                key={i}
                className="group relative p-8 bg-card rounded-2xl border border-border shadow-lg hover:shadow-2xl transition-all duration-300 animate-in card-hover"
                style={{ animationDelay: `${i * 100}ms` }}
              >
                <div className="absolute inset-0 rounded-2xl bg-gradient-to-br opacity-0 group-hover:opacity-5 transition-opacity" />

                <div className={`text-5xl mb-4 transform group-hover:scale-110 transition-transform`}>
                  {service.icon}
                </div>
                <h3 className="text-2xl font-bold mb-3 text-foreground">{service.title}</h3>
                <p className="text-muted-foreground leading-relaxed">{service.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="relative py-20 md:py-32">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {[
              { label: t("activePatients"), value: "10K+" },
              { label: t("licensedDoctors"), value: "500+" },
              { label: t("therapists"), value: "200+" },
              { label: t("therapyRooms"), value: "50+" },
            ].map((stat, i) => (
              <div
                key={i}
                className="text-center p-6 rounded-xl bg-card border border-border hover:border-primary/50 transition-all"
                style={{ animationDelay: `${i * 100}ms` }}
              >
                <div className="text-4xl md:text-5xl font-bold gradient-primary-text mb-2">{stat.value}</div>
                <p className="text-muted-foreground font-medium">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonial Section */}
      <section className="relative py-20 md:py-32 bg-gradient-to-b from-primary/5 to-transparent">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h2 className="text-4xl md:text-5xl font-bold mb-4 gradient-primary-text">
            {t("trustedByHealthcareProfessionals")}
          </h2>
          <p className="text-lg text-muted-foreground mb-12">{t("joinSmartHealthcare")}</p>

          <div className="grid md:grid-cols-2 gap-8">
            {[
              {
                quote: t("doctorAndersonQuote"),
                author: "Dr. Sarah Anderson",
                role: t("cardiologist"),
              },
              {
                quote: t("johnMartinezQuote"),
                author: "John Martinez",
                role: t("patient"),
              },
            ].map((testimonial, i) => (
              <div key={i} className="p-8 bg-card rounded-2xl border border-border shadow-lg">
                <p className="text-lg mb-4 text-foreground italic">"{testimonial.quote}"</p>
                <p className="font-semibold text-primary">{testimonial.author}</p>
                <p className="text-sm text-muted-foreground">{testimonial.role}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer CTA */}
      <section className="relative py-20 md:py-32 bg-gradient-to-r from-primary/20 via-secondary/20 to-accent/10">
        <div className="max-w-4xl mx-auto px-4 text-center space-y-8">
          <h2 className="text-4xl md:text-5xl font-bold">{t("readyToTransform")}</h2>
          <p className="text-lg text-muted-foreground">{t("joinSmartHealthcareToday")}</p>
          <Button
            onClick={() => router.push("/login")}
            className="px-10 py-7 bg-gradient-to-r from-primary to-secondary hover:shadow-xl text-primary-foreground text-lg rounded-xl font-semibold shadow-lg transition-all animate-bounce-mild"
          >
            {t("startYourJourney")}
          </Button>
        </div>
      </section>
    </main>
  )
}
