"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Sidebar } from "@/components/layout/sidebar"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card } from "@/components/ui/card"
import { useAppStore } from "@/lib/store"
import { Send, MessageCircle, Bot } from "lucide-react"
import { ThemeToggle } from "@/components/theme-toggle"
import { getTranslation } from "@/lib/translations"

const getChatbotResponses = (lang: string) => {
  const responses: Record<string, Record<string, string>> = {
    en: {
      "how to book":
        'To book a consultation: 1) Click "Book a Consultation" 2) Select a doctor 3) Describe symptoms 4) Choose date/time 5) Confirm booking.',
      prescription:
        "View prescriptions in your dashboard. They include medication details, dosage, and instructions. Digital prescriptions are encrypted and shareable.",
      therapy:
        "To schedule therapy: 1) Go to Schedule Therapy 2) Select therapist 3) Choose room 4) Pick date/time 5) Confirm. No room conflicts guaranteed.",
      appointment:
        "View all appointments in dashboard. Get notifications 24h and 1h before appointments. Click any to see details, reschedule, or cancel.",
      cancel: "To cancel, go to appointments and click cancel. Full refund provided.",
      doctor:
        "We have experienced doctors across Cardiology, Neurology, Dermatology, Psychiatry, and more. All are verified professionals.",
      payment:
        "We accept UPI, cards, digital wallets. Payments are secure and encrypted. See consultation fee before booking.",
      emergency:
        "For medical emergencies, contact your nearest hospital or emergency services. Our platform is for non-emergency consultations only.",
      "mental health":
        "We offer therapy for anxiety, depression, stress, and counseling. Our therapists are certified. Book in therapy section.",
      insurance: "Working on insurance integration. Currently out-of-pocket with detailed receipts for claims.",
      report: "Upload medical reports to your profile. Share with doctors during consultations for better diagnosis.",
      follow: "Follow-up consultations available after initial consultation. Doctor can recommend based on condition.",
      default:
        "I can help with booking consultations, scheduling therapy, viewing prescriptions, managing appointments, payments, reports, and more. What would you like help with?",
    },
    hi: {
      "how to book":
        'परामर्श बुक करने के लिए: 1) "परामर्श बुक करें" पर क्लिक करें 2) डॉक्टर चुनें 3) लक्षण बताएं 4) तारीख/समय चुनें 5) बुकिंग पुष्टि करें।',
      prescription: "अपने डैशबोर्ड में नुस्खे देखें। इसमें दवा का विवरण, खुराक और निर्देश शामिल हैं।",
      therapy: "थेरेपी शेड्यूल करने के लिए: 1) थेरेपी शेड्यूल पर जाएं 2) थेरेपिस्ट चुनें 3) कमरा चुनें 4) तारीख/समय चुनें 5) पुष्टि करें।",
      appointment: "डैशबोर्ड में सभी अपॉइंटमेंट देखें। अपॉइंटमेंट से 24 घंटे और 1 घंटे पहले सूचनाएं प्राप्त करें।",
      cancel: "रद्द करने के लिए, अपॉइंटमेंट पर जाएं और रद्द करें पर क्लिक करें। पूर्ण रिफंड प्रदान किया जाता है।",
      doctor: "हमारे पास कार्डियोलॉजी, न्यूरोलॉजी, डर्मेटोलॉजी, मनोचिकित्सा और अधिक में अनुभवी डॉक्टर हैं।",
      payment: "हम UPI, कार्ड, डिजिटल वॉलेट स्वीकार करते हैं। भुगतान सुरक्षित और एन्क्रिप्टेड हैं।",
      emergency: "चिकित्सा आपातकाल के लिए, अपने निकटतम अस्पताल या आपातकालीन सेवाओं से संपर्क करें।",
      "mental health": "हम चिंता, अवसाद, तनाव प्रबंधन और परामर्श के लिए थेरेपी प्रदान करते हैं।",
      insurance: "बीमा एकीकरण पर काम कर रहे हैं। वर्तमान में दावों के लिए विस्तृत रसीदों के साथ जेब से बाहर।",
      report: "अपनी प्रोफ़ाइल में चिकित्सा रिपोर्ट अपलोड करें। बेहतर निदान के लिए परामर्श के दौरान डॉक्टरों के साथ साझा करें।",
      follow: "प्रारंभिक परामर्श के बाद फॉलो-अप परामर्श उपलब्ध हैं।",
      default:
        "मैं परामर्श बुकिंग, थेरेपी शेड्यूलिंग, नुस्खे देखने, अपॉइंटमेंट प्रबंधित करने और अधिक में मदद कर सकता हूं। आप किस बारे में मदद चाहेंगे?",
    },
    es: {
      "how to book":
        'Para reservar consulta: 1) Haz clic en "Reservar Consulta" 2) Selecciona médico 3) Describe síntomas 4) Elige fecha/hora 5) Confirma reserva.',
      prescription: "Ve las recetas en tu panel. Incluyen detalles de medicamentos, dosis e instrucciones.",
      therapy:
        "Para programar terapia: 1) Ve a Programar Terapia 2) Selecciona terapeuta 3) Elige sala 4) Selecciona fecha/hora 5) Confirma.",
      appointment: "Ve todas las citas en el panel. Recibe notificaciones 24h y 1h antes de las citas.",
      cancel: "Para cancelar, ve a citas y haz clic en cancelar. Se proporciona reembolso completo.",
      doctor: "Tenemos médicos experimentados en Cardiología, Neurología, Dermatología, Psiquiatría y más.",
      payment: "Aceptamos UPI, tarjetas, billeteras digitales. Los pagos son seguros y encriptados.",
      emergency: "Para emergencias médicas, contacta con tu hospital más cercano o servicios de emergencia.",
      "mental health": "Ofrecemos terapia para ansiedad, depresión, manejo del estrés y asesoramiento.",
      insurance: "Trabajando en integración de seguros. Actualmente de bolsillo con recibos detallados para reclamos.",
      report: "Sube informes médicos a tu perfil. Compártelos con médicos durante las consultas.",
      follow: "Consultas de seguimiento disponibles después de la consulta inicial.",
      default:
        "Puedo ayudarte con reservar consultas, programar terapia, ver recetas, gestionar citas y más. ¿En qué te gustaría ayuda?",
    },
  }

  return responses[lang] || responses.en
}

export default function HelpPage() {
  const { currentUser, chatMessages, addChatMessage, currentLanguage } = useAppStore()
  const [input, setInput] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    scrollToBottom()
  }, [chatMessages])

  const findBotResponse = (userMessage: string, language: string): string => {
    const responses = getChatbotResponses(language)
    const lowerMessage = userMessage.toLowerCase()

    for (const [key, value] of Object.entries(responses)) {
      if (lowerMessage.includes(key)) {
        return value
      }
    }
    return responses.default
  }

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault()
    if (!input.trim()) return

    setIsLoading(true)

    addChatMessage({
      id: `msg${Date.now()}user`,
      sender: "user",
      message: input,
      timestamp: new Date(),
    })

    const botResponse = findBotResponse(input, currentLanguage)
    setTimeout(() => {
      addChatMessage({
        id: `msg${Date.now()}bot`,
        sender: "bot",
        message: botResponse,
        timestamp: new Date(),
      })
      setIsLoading(false)
    }, 800)

    setInput("")
  }

  if (!currentUser) {
    return <div className="flex items-center justify-center min-h-screen">Please log in</div>
  }

  return (
    <div className="flex min-h-screen bg-background">
      <Sidebar />

      <div className="flex-1 ml-64 p-8">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-4xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
              {getTranslation(currentLanguage, "help")}
            </h1>
            <p className="text-muted-foreground mt-2">{getTranslation(currentLanguage, "helpDescription")}</p>
          </div>
          <ThemeToggle />
        </div>

        <Card className="max-w-4xl mx-auto shadow-2xl border-primary/20">
          {/* Header */}
          <div className="bg-gradient-to-r from-primary to-secondary text-primary-foreground p-6 rounded-t-lg">
            <div className="flex items-center gap-3">
              <Bot className="w-8 h-8" />
              <div>
                <h2 className="text-2xl font-bold">{getTranslation(currentLanguage, "aiAssistant")}</h2>
                <p className="text-sm opacity-90">{getTranslation(currentLanguage, "aiAssistantSubtitle")}</p>
              </div>
            </div>
          </div>

          {/* Messages Area */}
          <div className="h-[500px] overflow-y-auto p-6 space-y-4 bg-gradient-to-b from-background to-primary/2">
            {chatMessages.length === 0 && (
              <div className="text-center text-muted-foreground py-12 space-y-3">
                <MessageCircle className="w-16 h-16 mx-auto text-primary/50" />
                <p className="font-semibold text-lg">{getTranslation(currentLanguage, "welcomeToHelp")}</p>
                <p className="text-sm">{getTranslation(currentLanguage, "askAnything")}</p>
              </div>
            )}

            {chatMessages.map((msg, index) => (
              <div
                key={msg.id}
                className={`flex ${msg.sender === "user" ? "justify-end" : "justify-start"} animate-slide-in-left`}
                style={{ animationDelay: `${index * 50}ms` }}
              >
                <div
                  className={`max-w-lg px-5 py-3 rounded-2xl text-sm leading-relaxed ${
                    msg.sender === "user"
                      ? "bg-gradient-to-r from-primary to-secondary text-primary-foreground rounded-br-none shadow-lg"
                      : "bg-muted text-foreground rounded-bl-none shadow-md border border-border/50"
                  }`}
                >
                  {msg.message}
                </div>
              </div>
            ))}

            {isLoading && (
              <div className="flex justify-start">
                <div className="bg-muted text-foreground rounded-2xl px-5 py-3 space-y-2">
                  <div className="flex gap-1">
                    <div className="w-2 h-2 bg-primary rounded-full animate-bounce" />
                    <div
                      className="w-2 h-2 bg-primary rounded-full animate-bounce"
                      style={{ animationDelay: "100ms" }}
                    />
                    <div
                      className="w-2 h-2 bg-primary rounded-full animate-bounce"
                      style={{ animationDelay: "200ms" }}
                    />
                  </div>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Input Area */}
          <form onSubmit={handleSendMessage} className="border-t border-border p-4 flex gap-3 bg-card">
            <Input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder={getTranslation(currentLanguage, "typeYourQuestion")}
              className="text-sm border-primary/30 focus:border-primary flex-1"
              disabled={isLoading}
            />
            <Button
              type="submit"
              size="lg"
              className="bg-gradient-to-r from-primary to-secondary hover:shadow-lg text-primary-foreground px-6"
              disabled={isLoading}
            >
              <Send className="w-5 h-5" />
            </Button>
          </form>
        </Card>

        {/* Quick Help Topics */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-8 max-w-4xl mx-auto">
          <Card
            className="p-4 hover:shadow-lg transition-shadow cursor-pointer"
            onClick={() => setInput("How to book a consultation?")}
          >
            <h3 className="font-semibold text-primary mb-2">{getTranslation(currentLanguage, "bookConsultation")}</h3>
            <p className="text-sm text-muted-foreground">{getTranslation(currentLanguage, "bookConsultationHelp")}</p>
          </Card>
          <Card
            className="p-4 hover:shadow-lg transition-shadow cursor-pointer"
            onClick={() => setInput("How do prescriptions work?")}
          >
            <h3 className="font-semibold text-primary mb-2">{getTranslation(currentLanguage, "prescriptions")}</h3>
            <p className="text-sm text-muted-foreground">{getTranslation(currentLanguage, "prescriptionsHelp")}</p>
          </Card>
          <Card
            className="p-4 hover:shadow-lg transition-shadow cursor-pointer"
            onClick={() => setInput("How to schedule therapy?")}
          >
            <h3 className="font-semibold text-primary mb-2">{getTranslation(currentLanguage, "scheduleTherapy")}</h3>
            <p className="text-sm text-muted-foreground">{getTranslation(currentLanguage, "therapyHelp")}</p>
          </Card>
        </div>
      </div>
    </div>
  )
}
