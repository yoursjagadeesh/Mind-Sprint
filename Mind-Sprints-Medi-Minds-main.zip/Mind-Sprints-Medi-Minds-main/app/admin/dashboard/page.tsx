"use client"

import { useRouter } from "next/navigation"
import { useEffect, useState } from "react"
import { useAppStore } from "@/lib/store"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { AuditLogViewer } from "@/components/audit-log-viewer"
import { RoleBasedAccess } from "@/components/role-based-access"
import { Badge } from "@/components/ui/badge"
import { Sidebar } from "@/components/layout/sidebar"
import { ThemeToggle } from "@/components/theme-toggle"
import { ConsultationDetailsDialog } from "@/components/consultation/consultation-details-dialog"
import { TherapyDetailsDialog } from "@/components/therapy/therapy-details-dialog"
import { PrescriptionDetailsDialog } from "@/components/prescription/prescription-details-dialog"
import type { Consultation, TherapySession, Prescription } from "@/lib/types"

export default function AdminDashboard() {
  const router = useRouter()
  const { currentUser, consultations, therapySessions, prescriptions } = useAppStore()
  const [selectedConsultation, setSelectedConsultation] = useState<Consultation | null>(null)
  const [selectedTherapy, setSelectedTherapy] = useState<TherapySession | null>(null)
  const [selectedPrescription, setSelectedPrescription] = useState<Prescription | null>(null)

  useEffect(() => {
    if (!currentUser || currentUser.role !== "admin") {
      router.push("/")
    }
  }, [currentUser, router])

  return (
    <RoleBasedAccess allowedRoles={["admin"]}>
      <Sidebar />
      <main className="min-h-screen bg-gradient-to-br from-background via-primary/5 to-background p-4 md:p-8 ml-64">
        <div className="max-w-7xl mx-auto space-y-8">
          {/* Header */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h1 className="text-4xl font-bold gradient-primary-text">Admin Dashboard</h1>
              <div className="flex items-center gap-3">
                <ThemeToggle />
                <Button
                  variant="outline"
                  onClick={() => {
                    useAppStore.setState({ currentUser: null })
                    router.push("/")
                  }}
                >
                  Logout
                </Button>
              </div>
            </div>
            <p className="text-muted-foreground">Manage system users, audit logs, and platform settings</p>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            {[
              { label: "Total Consultations", value: consultations.length, icon: "👨‍⚕️" },
              { label: "Therapy Sessions", value: therapySessions.length, icon: "💆" },
              { label: "Prescriptions", value: prescriptions.length, icon: "💊" },
              { label: "System Health", value: "98%", icon: "💚" },
            ].map((stat, i) => (
              <Card key={i} className="border-primary/20 bg-gradient-to-br from-card to-card/50">
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground">{stat.label}</p>
                      <p className="text-2xl font-bold text-foreground mt-1">{stat.value}</p>
                    </div>
                    <span className="text-3xl">{stat.icon}</span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Recent Consultations */}
            <Card className="border-primary/20">
              <CardHeader>
                <CardTitle>Recent Consultations</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {consultations.slice(0, 5).map((consultation) => (
                  <div
                    key={consultation.id}
                    onClick={() => setSelectedConsultation(consultation)}
                    className="p-3 bg-muted rounded-lg hover:bg-muted/70 transition-colors cursor-pointer"
                  >
                    <p className="font-medium text-sm">Patient: {consultation.patientId}</p>
                    <p className="text-xs text-muted-foreground">Dr. {consultation.doctorId}</p>
                    <Badge className="mt-1" variant={consultation.status === "completed" ? "default" : "secondary"}>
                      {consultation.status}
                    </Badge>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Recent Therapy Sessions */}
            <Card className="border-primary/20">
              <CardHeader>
                <CardTitle>Recent Therapy Sessions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {therapySessions.slice(0, 5).map((session) => (
                  <div
                    key={session.id}
                    onClick={() => setSelectedTherapy(session)}
                    className="p-3 bg-muted rounded-lg hover:bg-muted/70 transition-colors cursor-pointer"
                  >
                    <p className="font-medium text-sm">Patient: {session.patientId}</p>
                    <p className="text-xs text-muted-foreground">Room: {session.roomId}</p>
                    <Badge className="mt-1" variant={session.status === "completed" ? "default" : "secondary"}>
                      {session.status}
                    </Badge>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Recent Prescriptions */}
            <Card className="border-primary/20">
              <CardHeader>
                <CardTitle>Recent Prescriptions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {prescriptions.slice(0, 5).map((prescription) => (
                  <div
                    key={prescription.id}
                    onClick={() => setSelectedPrescription(prescription)}
                    className="p-3 bg-muted rounded-lg hover:bg-muted/70 transition-colors cursor-pointer"
                  >
                    <p className="font-medium text-sm">Patient: {prescription.patientId}</p>
                    <p className="text-xs text-muted-foreground">{prescription.medications.length} medications</p>
                    <p className="text-xs text-muted-foreground">{prescription.date.toLocaleDateString()}</p>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>

          {/* Audit Logs Viewer */}
          <AuditLogViewer />

          {/* User Management Section */}
          <Card className="border-primary/20">
            <CardHeader>
              <CardTitle>User Management</CardTitle>
              <CardDescription>Manage system users and their roles</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {["Receptionist", "Receptionist", "Doctor", "Therapist"].map((role, i) => (
                  <div
                    key={i}
                    className="p-4 bg-muted rounded-lg flex items-center justify-between hover:bg-muted/80 transition-colors"
                  >
                    <div>
                      <p className="font-semibold">User {i + 1}</p>
                      <p className="text-sm text-muted-foreground">user{i + 1}@hospital.com</p>
                    </div>
                    <Badge>{role}</Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </main>

      {selectedConsultation && (
        <ConsultationDetailsDialog
          consultation={selectedConsultation}
          open={!!selectedConsultation}
          onOpenChange={() => setSelectedConsultation(null)}
        />
      )}
      {selectedTherapy && (
        <TherapyDetailsDialog
          session={selectedTherapy}
          open={!!selectedTherapy}
          onOpenChange={() => setSelectedTherapy(null)}
        />
      )}
      {selectedPrescription && (
        <PrescriptionDetailsDialog
          prescription={selectedPrescription}
          open={!!selectedPrescription}
          onOpenChange={() => setSelectedPrescription(null)}
        />
      )}
    </RoleBasedAccess>
  )
}
