"use client"

import { useEffect } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useAppStore } from "@/lib/store"
import { Sidebar } from "@/components/layout/sidebar"
import { ThemeToggle } from "@/components/theme-toggle"

export default function ProfilePage() {
  const router = useRouter()
  const { currentUser, setCurrentUser } = useAppStore()

  useEffect(() => {
    if (!currentUser) {
      router.push("/")
    }
  }, [currentUser, router])

  if (!currentUser) return null

  return (
    <>
      <Sidebar />
      <main className="min-h-screen bg-background ml-64">
        <header className="border-b border-border bg-card sticky top-0 z-40">
          <div className="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
            <h1 className="text-2xl font-bold">My Profile</h1>
            <div className="flex items-center gap-4">
              <ThemeToggle />
              <Button variant="outline" onClick={() => router.back()}>
                Back
              </Button>
            </div>
          </div>
        </header>

        <div className="max-w-3xl mx-auto px-4 py-8">
          <Card>
            <CardHeader>
              <CardTitle>Profile Information</CardTitle>
              <CardDescription>View and manage your account details</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label>Name</Label>
                <Input value={currentUser.name} disabled />
              </div>
              <div>
                <Label>Email</Label>
                <Input value={currentUser.email} disabled />
              </div>
              <div>
                <Label>Role</Label>
                <Input value={currentUser.role} disabled className="capitalize" />
              </div>
              <Button className="w-full">Edit Profile</Button>
            </CardContent>
          </Card>
        </div>
      </main>
    </>
  )
}
