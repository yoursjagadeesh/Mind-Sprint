"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { useAppStore } from "@/lib/store"
import { NotificationCenter } from "@/components/notifications/notification-center"
import { Sidebar } from "@/components/layout/sidebar"
import { ThemeToggle } from "@/components/theme-toggle"
import { TherapyDetailsDialog } from "@/components/therapy/therapy-details-dialog"
import type { TherapySession } from "@/lib/types"

export default function TherapistDashboard() {
  const router = useRouter()
  const { currentUser, therapySessions, setCurrentUser, updateTherapySession, addNotification, addAuditLog } =
    useAppStore()
  const [selectedSession, setSelectedSession] = useState<TherapySession | null>(null)

  useEffect(() => {
    if (!currentUser || currentUser.role !== "therapist") {
      router.push("/")
    }
  }, [currentUser, router])

  const handleLogout = () => {
    setCurrentUser(null)
    router.push("/")
  }

  const handleMarkAsCompleted = (sessionId: string) => {
    updateTherapySession(sessionId, { status: "completed" })

    const session = therapySessions.find((s) => s.id === sessionId)
    if (session) {
      addNotification({
        id: `notif-therapy-${Date.now()}`,
        userId: session.patientId,
        message: `Your therapy session has been completed`,
        type: "info",
        read: false,
        timestamp: new Date(),
      })

      addAuditLog({
        id: `audit-${Date.now()}`,
        userId: currentUser?.id || "",
        userName: currentUser?.name || "",
        userRole: "therapist",
        action: "Marked therapy session as completed",
        entityType: "therapy_session",
        entityId: sessionId,
        timestamp: new Date(),
        status: "success",
      })
    }
  }

  if (!currentUser) return null

  const mySessions = therapySessions.filter((s) => s.therapistId === currentUser.id)

  return (
    <>
      <Sidebar />
      <main className="min-h-screen bg-background ml-64">
        {/* Header */}
        <header className="border-b border-border bg-card sticky top-0 z-40 animate-slide-down">
          <div className="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                <span className="text-primary-foreground font-bold">T</span>
              </div>
              <h1 className="text-2xl font-bold">Therapist Dashboard - {currentUser.name}</h1>
            </div>
            <div className="flex items-center gap-4">
              <ThemeToggle />
              <NotificationCenter />
              <Button variant="outline" onClick={handleLogout}>
                Logout
              </Button>
            </div>
          </div>
        </header>

        {/* Main Content */}
        <div className="max-w-7xl mx-auto px-4 py-8">
          {/* Stats */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
            {[
              { label: "Total Sessions", value: mySessions.length },
              { label: "Scheduled Sessions", value: mySessions.filter((s) => s.status === "scheduled").length },
              { label: "Completed Sessions", value: mySessions.filter((s) => s.status === "completed").length },
            ].map((stat) => (
              <Card key={stat.label} className="bg-green-50 dark:bg-green-950/30 border-0 animate-in">
                <CardContent className="pt-6">
                  <div className="text-3xl font-bold text-primary">{stat.value}</div>
                  <div className="text-sm text-muted-foreground">{stat.label}</div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Sessions List */}
          <Card className="border-primary/20 animate-in">
            <CardHeader>
              <CardTitle>Therapy Sessions</CardTitle>
              <CardDescription>Manage patient therapy sessions</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {mySessions.length === 0 ? (
                  <p className="text-muted-foreground">No therapy sessions scheduled</p>
                ) : (
                  mySessions.map((session) => (
                    <div
                      key={session.id}
                      onClick={() => setSelectedSession(session)}
                      className="p-4 border border-border rounded-lg hover:border-primary/50 hover:shadow-md transition-all cursor-pointer"
                    >
                      <div className="flex justify-between items-start mb-2">
                        <div>
                          <h4 className="font-semibold">Patient ID: {session.patientId}</h4>
                          <p className="text-sm text-muted-foreground">
                            {session.date.toLocaleDateString()} from {session.startTime} to {session.endTime}
                          </p>
                          <p className="text-sm text-muted-foreground">Room: {session.roomId}</p>
                        </div>
                        <span
                          className={`px-3 py-1 rounded-full text-xs font-medium ${
                            session.status === "scheduled"
                              ? "bg-blue-100 dark:bg-blue-950 text-blue-900 dark:text-blue-100"
                              : "bg-green-100 dark:bg-green-950 text-green-900 dark:text-green-100"
                          }`}
                        >
                          {session.status}
                        </span>
                      </div>
                      {session.notes && (
                        <p className="text-sm mb-3">
                          <strong>Notes:</strong> {session.notes}
                        </p>
                      )}
                      <div className="flex gap-2" onClick={(e) => e.stopPropagation()}>
                        <Button
                          size="sm"
                          className="bg-primary hover:bg-primary/90"
                          onClick={() => handleMarkAsCompleted(session.id)}
                          disabled={session.status === "completed"}
                        >
                          {session.status === "completed" ? "Completed" : "Mark as Completed"}
                        </Button>
                        <Button size="sm" variant="outline" onClick={() => setSelectedSession(session)}>
                          View Details
                        </Button>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </main>

      {selectedSession && (
        <TherapyDetailsDialog
          session={selectedSession}
          open={!!selectedSession}
          onOpenChange={() => setSelectedSession(null)}
        />
      )}
    </>
  )
}
