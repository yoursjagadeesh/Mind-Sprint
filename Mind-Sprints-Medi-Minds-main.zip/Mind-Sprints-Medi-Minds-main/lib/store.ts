import { create } from "zustand"
import type {
  User,
  Patient,
  Doctor,
  Consultation,
  Prescription,
  TherapySession,
  Notification,
  ChatMessage,
  AuditLog,
  Language,
} from "./types"

interface AppStore {
  currentUser: User | null
  patients: Patient[]
  doctors: Doctor[]
  consultations: Consultation[]
  prescriptions: Prescription[]
  therapySessions: TherapySession[]
  notifications: Notification[]
  chatMessages: ChatMessage[]
  auditLogs: AuditLog[]
  currentLanguage: Language

  setCurrentUser: (user: User | null) => void
  setLanguage: (language: Language) => void
  addPatient: (patient: Patient) => void
  addNotification: (notification: Notification) => void
  markNotificationAsRead: (id: string) => void
  addChatMessage: (message: ChatMessage) => void
  addConsultation: (consultation: Consultation) => void
  addPrescription: (prescription: Prescription) => void
  addTherapySession: (session: TherapySession) => void
  updateConsultation: (id: string, data: Partial<Consultation>) => void
  updateTherapySession: (id: string, data: Partial<TherapySession>) => void
  addAuditLog: (log: AuditLog) => void
  getAuditLogs: (filters?: Partial<AuditLog>) => AuditLog[]
}

export const useAppStore = create<AppStore>((set, get) => ({
  currentUser: null,
  patients: [],
  doctors: [],
  consultations: [],
  prescriptions: [],
  therapySessions: [],
  notifications: [],
  chatMessages: [],
  auditLogs: [],
  currentLanguage: "en",

  setCurrentUser: (user) => set({ currentUser: user }),

  setLanguage: (language) => set({ currentLanguage: language }),

  addPatient: (patient) =>
    set((state) => ({
      patients: [...state.patients, patient],
    })),

  addNotification: (notification) =>
    set((state) => ({
      notifications: [notification, ...state.notifications].slice(0, 50),
    })),

  markNotificationAsRead: (id) =>
    set((state) => ({
      notifications: state.notifications.map((n) => (n.id === id ? { ...n, read: true } : n)),
    })),

  addChatMessage: (message) =>
    set((state) => ({
      chatMessages: [...state.chatMessages, message].slice(-100),
    })),

  addConsultation: (consultation) =>
    set((state) => ({
      consultations: [...state.consultations, consultation],
    })),

  addPrescription: (prescription) =>
    set((state) => ({
      prescriptions: [...state.prescriptions, prescription],
    })),

  addTherapySession: (session) =>
    set((state) => ({
      therapySessions: [...state.therapySessions, session],
    })),

  updateConsultation: (id, data) =>
    set((state) => ({
      consultations: state.consultations.map((c) => (c.id === id ? { ...c, ...data } : c)),
    })),

  updateTherapySession: (id, data) =>
    set((state) => ({
      therapySessions: state.therapySessions.map((s) => (s.id === id ? { ...s, ...data } : s)),
    })),

  addAuditLog: (log) =>
    set((state) => ({
      auditLogs: [log, ...state.auditLogs].slice(0, 1000),
    })),

  getAuditLogs: (filters) => {
    const { auditLogs } = get()
    if (!filters) return auditLogs
    return auditLogs.filter((log) => {
      if (filters.userRole && log.userRole !== filters.userRole) return false
      if (filters.action && !log.action.toLowerCase().includes(filters.action.toLowerCase())) return false
      if (filters.entityType && log.entityType !== filters.entityType) return false
      if (filters.status && log.status !== filters.status) return false
      return true
    })
  },
}))
