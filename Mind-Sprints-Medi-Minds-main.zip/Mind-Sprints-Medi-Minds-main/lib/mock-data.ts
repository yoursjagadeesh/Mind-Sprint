import type { Doctor, Room } from "./types"

const now = new Date()

export const mockDoctors: Doctor[] = [
  {
    id: "doc1",
    email: "dr.sharma@medi.com",
    password: "password123",
    name: "Dr. Rajesh Sharma",
    role: "doctor",
    specialization: "Cardiology",
    licenseNumber: "MED001",
    experience: 15,
    consultationFee: 500,
    createdAt: new Date(),
    availableSlots: [
      {
        id: "slot1",
        startTime: new Date(now.getTime() + 86400000),
        endTime: new Date(now.getTime() + 86400000 + 1800000),
        isBooked: false,
      },
    ],
  },
  {
    id: "doc2",
    email: "dr.patel@medi.com",
    password: "password123",
    name: "Dr. Priya Patel",
    role: "doctor",
    specialization: "Neurology",
    licenseNumber: "MED002",
    experience: 12,
    consultationFee: 450,
    createdAt: new Date(),
    availableSlots: [
      {
        id: "slot2",
        startTime: new Date(now.getTime() + 172800000),
        endTime: new Date(now.getTime() + 172800000 + 1800000),
        isBooked: false,
      },
    ],
  },
]

export const mockTherapists = [
  {
    id: "ther1",
    email: "therapist.john@medi.com",
    password: "password123",
    name: "John Wilson",
    role: "therapist" as const,
    specialization: "Physiotherapy",
    createdAt: new Date(),
    availableSlots: [],
    roomAssignments: [],
  },
]

export const mockRooms: Room[] = [
  {
    id: "room1",
    name: "Therapy Room A",
    capacity: 2,
    amenities: ["Mat", "Parallel Bars", "Mirror"],
  },
  {
    id: "room2",
    name: "Therapy Room B",
    capacity: 2,
    amenities: ["Treadmill", "Weights", "Mirror"],
  },
  {
    id: "room3",
    name: "Consultation Room 1",
    capacity: 3,
    amenities: ["Desk", "Computer", "Privacy Screen"],
  },
]
