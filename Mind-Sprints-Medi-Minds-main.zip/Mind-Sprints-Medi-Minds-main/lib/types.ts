export interface User {
  id: string
  email: string
  password: string
  name: string
  role: "patient" | "doctor" | "therapist" | "admin" | "receptionist"
  createdAt: Date
  language?: Language
}

export interface Patient extends User {
  role: "patient"
  dateOfBirth: string
  gender: string
  phone: string
  address: string
  medicalHistory: string
  allergies: string[]
}

export interface Doctor extends User {
  role: "doctor"
  specialization: string
  licenseNumber: string
  experience: number
  availableSlots: TimeSlot[]
  consultationFee: number
}

export interface Therapist extends User {
  role: "therapist"
  specialization: string
  availableSlots: TimeSlot[]
  roomAssignments: RoomAssignment[]
}

export interface TimeSlot {
  id: string
  startTime: Date
  endTime: Date
  isBooked: boolean
}

export interface Consultation {
  id: string
  patientId: string
  doctorId: string
  date: Date
  time: string
  notes: string
  status: "scheduled" | "completed" | "cancelled"
  symptoms: string
}

export interface Prescription {
  id: string
  consultationId: string
  patientId: string
  doctorId: string
  medications: Medication[]
  diagnoses: string[]
  instructions: string
  createdAt: Date
}

export interface Medication {
  id: string
  name: string
  dosage: string
  frequency: string
  duration: string
  sideEffects?: string
}

export interface TherapySession {
  id: string
  patientId: string
  therapistId: string
  roomId: string
  date: Date
  startTime: string
  endTime: string
  status: "scheduled" | "completed" | "cancelled"
  notes?: string
}

export interface Room {
  id: string
  name: string
  capacity: number
  amenities: string[]
}

export interface RoomAssignment {
  roomId: string
  date: Date
  startTime: string
  endTime: string
}

export interface Notification {
  id: string
  userId: string // This ensures notifications are user-specific
  title: string
  message: string
  type: "appointment" | "prescription" | "therapy" | "system"
  read: boolean
  createdAt: Date
}

export interface ChatMessage {
  id: string
  sender: "user" | "bot"
  message: string
  timestamp: Date
}

export type Language = "en" | "es" | "hi" | "te" | "ta" | "kn" | "bn" | "mr" | "gu" | "pa" | "fr" | "pt"

export interface AuditLog {
  id: string
  userId: string
  userName: string
  userRole: "patient" | "doctor" | "therapist" | "admin" | "receptionist"
  action: string
  description: string
  entityType: "patient" | "consultation" | "prescription" | "therapy" | "user"
  entityId: string
  timestamp: Date
  ipAddress?: string
  status: "success" | "failed"
  changes?: Record<string, any>
}
