"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import type { Prescription } from "@/lib/types"

interface PrescriptionViewerProps {
  prescription: Prescription
  onDownload?: () => void
}

export function PrescriptionViewer({ prescription, onDownload }: PrescriptionViewerProps) {
  return (
    <Card className="border-primary/20 animate-in">
      <CardHeader>
        <CardTitle>Digital Prescription</CardTitle>
        <CardDescription>Date: {new Date(prescription.createdAt).toLocaleDateString()}</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="border-b border-border pb-4">
          <h3 className="font-semibold text-sm mb-2">Diagnoses</h3>
          <ul className="space-y-1">
            {prescription.diagnoses.map((diagnosis, idx) => (
              <li key={idx} className="text-sm text-muted-foreground">
                • {diagnosis}
              </li>
            ))}
          </ul>
        </div>

        <div className="border-b border-border pb-4">
          <h3 className="font-semibold text-sm mb-3">Medications</h3>
          <div className="space-y-3">
            {prescription.medications.map((med) => (
              <div key={med.id} className="p-3 bg-muted rounded-lg">
                <div className="font-medium text-sm">{med.name}</div>
                <div className="text-xs text-muted-foreground mt-1">
                  <p>Dosage: {med.dosage}</p>
                  <p>Frequency: {med.frequency}</p>
                  <p>Duration: {med.duration}</p>
                  {med.sideEffects && <p>Side Effects: {med.sideEffects}</p>}
                </div>
              </div>
            ))}
          </div>
        </div>

        <div>
          <h3 className="font-semibold text-sm mb-2">Instructions</h3>
          <p className="text-sm text-muted-foreground">{prescription.instructions}</p>
        </div>

        {onDownload && (
          <Button onClick={onDownload} className="w-full bg-accent hover:bg-accent/90">
            Download Prescription
          </Button>
        )}
      </CardContent>
    </Card>
  )
}
