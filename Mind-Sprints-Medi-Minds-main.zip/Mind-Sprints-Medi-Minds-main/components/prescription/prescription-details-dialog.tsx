"use client"

import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import type { Prescription } from "@/lib/types"
import { Download, Pill, FileText } from "lucide-react"

interface PrescriptionDetailsDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  prescription: Prescription | null
}

export function PrescriptionDetailsDialog({ open, onOpenChange, prescription }: PrescriptionDetailsDialogProps) {
  if (!prescription) return null

  const handleDownload = () => {
    const content = `DIGITAL PRESCRIPTION
Date: ${new Date(prescription.createdAt).toLocaleDateString()}
Doctor ID: ${prescription.doctorId}
Patient ID: ${prescription.patientId}

DIAGNOSES:
${prescription.diagnoses.map((d, i) => `${i + 1}. ${d}`).join("\n")}

MEDICATIONS:
${prescription.medications
  .map(
    (m, i) => `
${i + 1}. ${m.name}
   Dosage: ${m.dosage}
   Frequency: ${m.frequency}
   Duration: ${m.duration}
   ${m.sideEffects ? `Side Effects: ${m.sideEffects}` : ""}
`,
  )
  .join("\n")}

INSTRUCTIONS:
${prescription.instructions}
`

    const blob = new Blob([content], { type: "text/plain" })
    const url = window.URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `prescription_${prescription.id}_${new Date().toISOString().split("T")[0]}.txt`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    window.URL.revokeObjectURL(url)
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl flex items-center gap-2">
            <span className="text-3xl">💊</span>
            Digital Prescription
          </DialogTitle>
          <p className="text-sm text-muted-foreground">Date: {new Date(prescription.createdAt).toLocaleDateString()}</p>
        </DialogHeader>
        <div className="space-y-6 mt-4">
          <div className="p-4 bg-blue-50 dark:bg-blue-950/20 rounded-lg">
            <div className="flex items-start gap-3">
              <FileText className="h-5 w-5 text-blue-600 dark:text-blue-400 mt-1" />
              <div className="flex-1">
                <p className="text-sm font-medium text-muted-foreground mb-2">Diagnoses</p>
                <ul className="space-y-1">
                  {prescription.diagnoses.map((diagnosis, idx) => (
                    <li key={idx} className="text-base">
                      • {diagnosis}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>

          <div className="space-y-3">
            <div className="flex items-center gap-2 mb-3">
              <Pill className="h-5 w-5 text-purple-600 dark:text-purple-400" />
              <h3 className="font-semibold text-lg">Medications</h3>
            </div>
            {prescription.medications.map((med, idx) => (
              <div
                key={med.id}
                className="p-4 bg-purple-50 dark:bg-purple-950/20 rounded-lg border-l-4 border-purple-500"
              >
                <div className="font-semibold text-base mb-2">
                  {idx + 1}. {med.name}
                </div>
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div>
                    <span className="text-muted-foreground">Dosage:</span>{" "}
                    <span className="font-medium">{med.dosage}</span>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Frequency:</span>{" "}
                    <span className="font-medium">{med.frequency}</span>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Duration:</span>{" "}
                    <span className="font-medium">{med.duration}</span>
                  </div>
                  {med.sideEffects && (
                    <div className="col-span-2">
                      <span className="text-muted-foreground">Side Effects:</span>{" "}
                      <span className="text-orange-600 dark:text-orange-400">{med.sideEffects}</span>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>

          <div className="p-4 bg-green-50 dark:bg-green-950/20 rounded-lg">
            <p className="text-sm font-medium text-muted-foreground mb-2">Instructions</p>
            <p className="text-base">{prescription.instructions}</p>
          </div>

          <Button onClick={handleDownload} className="w-full bg-primary hover:bg-primary/90">
            <Download className="h-4 w-4 mr-2" />
            Download Prescription
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}
