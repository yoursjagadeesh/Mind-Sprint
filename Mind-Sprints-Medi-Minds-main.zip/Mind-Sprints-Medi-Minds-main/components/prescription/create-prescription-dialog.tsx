"use client"

import type React from "react"

import { useState } from "react"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { useAppStore } from "@/lib/store"
import { Plus, X } from "lucide-react"

interface Medication {
  id: string
  name: string
  dosage: string
  frequency: string
  duration: string
  sideEffects?: string
}

interface CreatePrescriptionDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  consultationId: string
  patientId: string
}

export function CreatePrescriptionDialog({
  open,
  onOpenChange,
  consultationId,
  patientId,
}: CreatePrescriptionDialogProps) {
  const { currentUser, addPrescription, addNotification, addAuditLog } = useAppStore()
  const [diagnoses, setDiagnoses] = useState("")
  const [instructions, setInstructions] = useState("")
  const [medications, setMedications] = useState<Medication[]>([
    { id: "1", name: "", dosage: "", frequency: "", duration: "", sideEffects: "" },
  ])

  const addMedication = () => {
    setMedications([
      ...medications,
      { id: Date.now().toString(), name: "", dosage: "", frequency: "", duration: "", sideEffects: "" },
    ])
  }

  const removeMedication = (id: string) => {
    setMedications(medications.filter((med) => med.id !== id))
  }

  const updateMedication = (id: string, field: keyof Medication, value: string) => {
    setMedications(medications.map((med) => (med.id === id ? { ...med, [field]: value } : med)))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    const newPrescription = {
      id: `rx${Date.now()}`,
      consultationId,
      patientId,
      doctorId: currentUser?.id || "",
      medications: medications.filter((med) => med.name && med.dosage),
      diagnoses: diagnoses
        .split(",")
        .map((d) => d.trim())
        .filter(Boolean),
      instructions,
      createdAt: new Date(),
    }

    addPrescription(newPrescription)

    // Add notification
    addNotification({
      id: `notif${Date.now()}`,
      userId: patientId,
      title: "New Prescription",
      message: `Dr. ${currentUser?.name} has created a new prescription for you.`,
      type: "prescription",
      read: false,
      createdAt: new Date(),
    })

    // Add audit log
    addAuditLog({
      id: `audit${Date.now()}`,
      userId: currentUser?.id || "",
      userName: currentUser?.name || "",
      userRole: currentUser?.role || "doctor",
      action: "Created Prescription",
      entityType: "prescription",
      entityId: newPrescription.id,
      timestamp: new Date(),
      status: "success",
    })

    // Reset form
    setDiagnoses("")
    setInstructions("")
    setMedications([{ id: "1", name: "", dosage: "", frequency: "", duration: "", sideEffects: "" }])

    onOpenChange(false)
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Create Digital Prescription</DialogTitle>
          <DialogDescription>Fill in the prescription details for the patient</DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Diagnoses */}
          <div className="space-y-2">
            <Label htmlFor="diagnoses">Diagnoses (comma-separated)</Label>
            <Input
              id="diagnoses"
              placeholder="e.g., Common Cold, Viral Fever"
              value={diagnoses}
              onChange={(e) => setDiagnoses(e.target.value)}
              required
            />
          </div>

          {/* Medications */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <Label>Medications</Label>
              <Button type="button" onClick={addMedication} size="sm" variant="outline">
                <Plus className="h-4 w-4 mr-1" /> Add Medication
              </Button>
            </div>

            {medications.map((med, index) => (
              <div key={med.id} className="p-4 border border-border rounded-lg space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-semibold">Medication {index + 1}</span>
                  {medications.length > 1 && (
                    <Button type="button" variant="ghost" size="sm" onClick={() => removeMedication(med.id)}>
                      <X className="h-4 w-4" />
                    </Button>
                  )}
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <Label htmlFor={`name-${med.id}`}>Medicine Name</Label>
                    <Input
                      id={`name-${med.id}`}
                      value={med.name}
                      onChange={(e) => updateMedication(med.id, "name", e.target.value)}
                      placeholder="e.g., Amoxicillin"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor={`dosage-${med.id}`}>Dosage</Label>
                    <Input
                      id={`dosage-${med.id}`}
                      value={med.dosage}
                      onChange={(e) => updateMedication(med.id, "dosage", e.target.value)}
                      placeholder="e.g., 500mg"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor={`frequency-${med.id}`}>Frequency</Label>
                    <Input
                      id={`frequency-${med.id}`}
                      value={med.frequency}
                      onChange={(e) => updateMedication(med.id, "frequency", e.target.value)}
                      placeholder="e.g., Twice daily"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor={`duration-${med.id}`}>Duration</Label>
                    <Input
                      id={`duration-${med.id}`}
                      value={med.duration}
                      onChange={(e) => updateMedication(med.id, "duration", e.target.value)}
                      placeholder="e.g., 7 days"
                      required
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor={`sideEffects-${med.id}`}>Side Effects (optional)</Label>
                  <Input
                    id={`sideEffects-${med.id}`}
                    value={med.sideEffects}
                    onChange={(e) => updateMedication(med.id, "sideEffects", e.target.value)}
                    placeholder="e.g., May cause drowsiness"
                  />
                </div>
              </div>
            ))}
          </div>

          {/* Instructions */}
          <div className="space-y-2">
            <Label htmlFor="instructions">Additional Instructions</Label>
            <Textarea
              id="instructions"
              placeholder="e.g., Take with food. Complete the full course. Avoid alcohol."
              value={instructions}
              onChange={(e) => setInstructions(e.target.value)}
              rows={4}
              required
            />
          </div>

          <div className="flex gap-3">
            <Button type="submit" className="flex-1 bg-primary hover:bg-primary/90">
              Create Prescription
            </Button>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  )
}
