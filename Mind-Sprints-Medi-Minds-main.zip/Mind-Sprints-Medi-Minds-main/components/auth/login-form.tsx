"use client"

import type React from "react"
import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { useAppStore } from "@/lib/store"
import { mockDoctors, mockTherapists } from "@/lib/mock-data"
import { ThemeToggle } from "@/components/theme-toggle"
import { getTranslation } from "@/lib/translations"
import type { Language } from "@/lib/types"

export function LoginForm() {
  const router = useRouter()
  const { setCurrentUser, currentLanguage, setLanguage } = useAppStore()
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [error, setError] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [role, setRole] = useState<"patient" | "doctor" | "therapist" | "admin" | "receptionist">("patient")

  const t = (key: any) => getTranslation(currentLanguage, key)

  const handleLanguageChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setLanguage(e.target.value as Language)
  }

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    setIsLoading(true)

    try {
      let user = null

      if (role === "doctor") {
        user = mockDoctors.find((d) => d.email === email && d.password === password)
      } else if (role === "therapist") {
        user = mockTherapists.find((t) => t.email === email && t.password === password)
      } else if (role === "admin") {
        if (email === "admin@smart.com" && password === "admin123") {
          user = {
            id: "admin1",
            email,
            password,
            name: "Admin User",
            role: "admin" as const,
            createdAt: new Date(),
            language: currentLanguage,
          }
        }
      } else if (role === "receptionist") {
        if (email === "reception@smart.com" && password === "reception123") {
          user = {
            id: "receptionist1",
            email,
            password,
            name: "Receptionist User",
            role: "receptionist" as const,
            createdAt: new Date(),
            language: currentLanguage,
          }
        }
      } else {
        user = {
          id: "patient1",
          email,
          password,
          name: "John Patient",
          role: "patient" as const,
          createdAt: new Date(),
          language: currentLanguage,
        }
      }

      if (user) {
        const auditLog = {
          id: `audit-${Date.now()}`,
          userId: user.id,
          userName: user.name,
          userRole: user.role,
          action: `Login as ${user.role}`,
          description: `User logged in successfully`,
          entityType: "user" as const,
          entityId: user.id,
          timestamp: new Date(),
          status: "success" as const,
        }
        useAppStore.setState({ auditLogs: [auditLog, ...useAppStore.getState().auditLogs] })

        setCurrentUser({ ...user, language: currentLanguage })

        if (role === "doctor") {
          router.push("/doctor/dashboard")
        } else if (role === "therapist") {
          router.push("/therapist/dashboard")
        } else if (role === "admin") {
          router.push("/admin/dashboard")
        } else if (role === "receptionist") {
          router.push("/receptionist/dashboard")
        } else {
          router.push("/patient/dashboard")
        }
      } else {
        setError(t("invalidCredentials") || "Invalid credentials. Please check your email and password.")
      }
    } catch (err) {
      setError(t("loginFailed") || "Login failed. Please try again.")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/20 via-background to-secondary/10 dark:from-primary/5 dark:via-background dark:to-secondary/5 flex items-center justify-center p-4 animate-fade-in">
      {/* Theme Toggle - Top Right */}
      <div className="absolute top-4 right-4 z-50">
        <ThemeToggle />
      </div>

      <div className="absolute top-4 left-4 z-50">
        <div className="flex items-center gap-2 bg-card/95 backdrop-blur-sm px-3 py-2 rounded-lg border border-primary/20 shadow-md">
          <span className="text-xs">🌐</span>
          <select
            value={currentLanguage}
            onChange={handleLanguageChange}
            className="bg-transparent border-none outline-none text-xs font-medium cursor-pointer text-foreground"
          >
            <option value="en">English</option>
            <option value="hi">हिन्दी</option>
            <option value="te">తెలుగు</option>
            <option value="ta">தமிழ்</option>
            <option value="kn">ಕನ್ನಡ</option>
            <option value="bn">বাঙ্গালী</option>
            <option value="mr">मराठी</option>
            <option value="gu">ગુજરાતી</option>
            <option value="pa">ਪੰਜਾਬੀ</option>
            <option value="es">Español</option>
            <option value="fr">Français</option>
            <option value="pt">Português</option>
          </select>
        </div>
      </div>

      {/* Decorative backgrounds */}
      <div className="absolute top-0 left-0 w-96 h-96 bg-primary/10 dark:bg-primary/5 rounded-full blur-3xl" />
      <div className="absolute bottom-0 right-0 w-96 h-96 bg-secondary/10 dark:bg-secondary/5 rounded-full blur-3xl" />

      <Card className="w-full max-w-md shadow-2xl border-primary/30 animate-scale-in relative z-10 bg-card dark:bg-card">
        <CardHeader className="space-y-4 bg-gradient-to-r from-primary/5 to-secondary/5 dark:from-primary/10 dark:to-secondary/10 pb-8">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-gradient-to-br from-primary to-secondary rounded-xl flex items-center justify-center shadow-lg">
              <span className="text-2xl">⚕️</span>
            </div>
            <div>
              <CardTitle className="text-2xl font-bold gradient-primary-text">{t("appTitle")}</CardTitle>
              <CardDescription className="text-xs mt-1">{t("signIn")}</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-6 pt-6">
          <form onSubmit={handleLogin} className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-semibold">{t("selectRole")}</label>
              <select
                value={role}
                onChange={(e) => setRole(e.target.value as any)}
                className="w-full px-4 py-3 rounded-lg border-2 border-primary/30 bg-background dark:bg-input text-foreground focus:border-primary focus:ring-2 focus:ring-primary/30 outline-none transition-all cursor-pointer font-medium"
              >
                <option value="patient">👤 {t("patient")}</option>
                <option value="doctor">👨‍⚕️ {t("doctor")}</option>
                <option value="therapist">🧘 {t("therapist")}</option>
                <option value="admin">👔 Admin</option>
                <option value="receptionist">📋 Receptionist</option>
              </select>
            </div>

            {/* Error Message */}
            {error && (
              <Alert variant="destructive" className="animate-slide-down">
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            {/* Email Input */}
            <div className="space-y-2">
              <label className="text-sm font-semibold">{t("email")}</label>
              <Input
                type="email"
                placeholder="your@email.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                disabled={isLoading}
                className="border-primary/30 focus:border-primary focus:ring-primary/30 dark:bg-input dark:border-primary/20"
              />
            </div>

            {/* Password Input */}
            <div className="space-y-2">
              <label className="text-sm font-semibold">{t("password")}</label>
              <Input
                type="password"
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                disabled={isLoading}
                className="border-primary/30 focus:border-primary focus:ring-primary/30 dark:bg-input dark:border-primary/20"
              />
            </div>

            {/* Demo Credentials */}
            <div className="bg-gradient-to-br from-blue-50 to-blue-100/50 dark:from-blue-950/40 dark:to-blue-950/20 p-4 rounded-xl border border-blue-200/50 dark:border-blue-800/50 text-sm space-y-2">
              <p className="font-bold text-blue-900 dark:text-blue-200 flex items-center gap-2">
                <span>💡</span> Demo Credentials:
              </p>
              <p className="text-xs text-blue-800 dark:text-blue-300 font-mono">
                Doctor: dr.sharma@medi.com / password123
              </p>
              <p className="text-xs text-blue-800 dark:text-blue-300 font-mono">
                Therapist: therapist.john@medi.com / password123
              </p>
              <p className="text-xs text-blue-800 dark:text-blue-300 font-mono">Admin: admin@smart.com / admin123</p>
              <p className="text-xs text-blue-800 dark:text-blue-300 font-mono">
                Receptionist: reception@smart.com / reception123
              </p>
              <p className="text-xs text-blue-800 dark:text-blue-300 font-mono">Patient: any email / any password</p>
            </div>

            {/* Submit Button */}
            <Button
              type="submit"
              className="w-full bg-gradient-to-r from-primary to-secondary hover:shadow-lg text-primary-foreground font-semibold py-6 rounded-xl transition-all duration-300"
              disabled={isLoading}
            >
              {isLoading ? (
                <div className="flex items-center gap-2">
                  <span className="inline-block w-4 h-4 border-2 border-primary-foreground border-t-transparent rounded-full animate-spin" />
                  {t("loading")}
                </div>
              ) : (
                t("signIn")
              )}
            </Button>
          </form>

          <div className="relative">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-border dark:border-border/50" />
            </div>
            <div className="relative flex justify-center text-sm">
              <span className="px-2 bg-card text-muted-foreground dark:bg-card">New to Smart Healthcare?</span>
            </div>
          </div>

          <Button
            variant="outline"
            className="w-full border-2 border-primary text-primary hover:bg-primary/5 font-semibold py-6 rounded-xl transition-all bg-transparent dark:border-primary/50 dark:hover:bg-primary/10"
            onClick={() => router.push("/signup")}
          >
            {t("signUp")}
          </Button>
        </CardContent>
      </Card>
    </div>
  )
}
