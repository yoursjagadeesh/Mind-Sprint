"use client"

import { useAppStore } from "@/lib/store"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { useState } from "react"

export function AuditLogViewer() {
  const { auditLogs, getAuditLogs } = useAppStore()
  const [filterAction, setFilterAction] = useState("")
  const [filterUser, setFilterUser] = useState("")

  const filteredLogs = getAuditLogs().filter((log) => {
    if (filterAction && !log.action.toLowerCase().includes(filterAction.toLowerCase())) return false
    if (filterUser && !log.userName.toLowerCase().includes(filterUser.toLowerCase())) return false
    return true
  })

  const getStatusColor = (status: string) => {
    return status === "success"
      ? "bg-green-500/20 text-green-700 dark:text-green-400"
      : "bg-red-500/20 text-red-700 dark:text-red-400"
  }

  const getRoleColor = (role: string) => {
    const colors: Record<string, string> = {
      admin: "bg-purple-500/20 text-purple-700 dark:text-purple-400",
      doctor: "bg-blue-500/20 text-blue-700 dark:text-blue-400",
      therapist: "bg-green-500/20 text-green-700 dark:text-green-400",
      patient: "bg-gray-500/20 text-gray-700 dark:text-gray-400",
      receptionist: "bg-orange-500/20 text-orange-700 dark:text-orange-400",
    }
    return colors[role] || colors.patient
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>Audit Logs</CardTitle>
        <CardDescription>Track system activities and user actions</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Filters */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
          <Input
            placeholder="Filter by action..."
            value={filterAction}
            onChange={(e) => setFilterAction(e.target.value)}
            className="border-primary/30 focus:border-primary"
          />
          <Input
            placeholder="Filter by user..."
            value={filterUser}
            onChange={(e) => setFilterUser(e.target.value)}
            className="border-primary/30 focus:border-primary"
          />
        </div>

        {/* Logs Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border">
                <th className="text-left py-3 px-4 font-semibold">Timestamp</th>
                <th className="text-left py-3 px-4 font-semibold">User</th>
                <th className="text-left py-3 px-4 font-semibold">Role</th>
                <th className="text-left py-3 px-4 font-semibold">Action</th>
                <th className="text-left py-3 px-4 font-semibold">Entity</th>
                <th className="text-left py-3 px-4 font-semibold">Status</th>
              </tr>
            </thead>
            <tbody>
              {filteredLogs.slice(0, 20).map((log) => (
                <tr key={log.id} className="border-b border-border hover:bg-muted/50 transition-colors">
                  <td className="py-3 px-4 text-xs text-muted-foreground">
                    {new Date(log.timestamp).toLocaleString()}
                  </td>
                  <td className="py-3 px-4 font-medium">{log.userName}</td>
                  <td className="py-3 px-4">
                    <Badge className={getRoleColor(log.userRole)}>{log.userRole}</Badge>
                  </td>
                  <td className="py-3 px-4">{log.action}</td>
                  <td className="py-3 px-4 text-xs">
                    <Badge variant="outline">
                      {log.entityType} - {log.entityId.slice(0, 8)}
                    </Badge>
                  </td>
                  <td className="py-3 px-4">
                    <Badge className={getStatusColor(log.status)}>{log.status}</Badge>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {filteredLogs.length === 0 && (
          <div className="text-center py-8 text-muted-foreground">No audit logs found matching your criteria</div>
        )}

        <div className="text-xs text-muted-foreground mt-4">
          Showing {Math.min(filteredLogs.length, 20)} of {filteredLogs.length} logs
        </div>
      </CardContent>
    </Card>
  )
}
