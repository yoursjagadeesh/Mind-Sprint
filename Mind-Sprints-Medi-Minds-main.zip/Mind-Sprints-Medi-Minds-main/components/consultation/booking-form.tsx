"use client"

import { Input } from "@/components/ui/input"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { useAppStore } from "@/lib/store"
import { mockDoctors } from "@/lib/mock-data"

export function ConsultationBookingForm() {
  const { addConsultation, addNotification } = useAppStore()
  const [selectedDoctor, setSelectedDoctor] = useState("")
  const [symptoms, setSymptoms] = useState("")
  const [date, setDate] = useState("")
  const [time, setTime] = useState("")
  const [successMessage, setSuccessMessage] = useState("")

  const handleBooking = (e: React.FormEvent) => {
    e.preventDefault()

    const consultation = {
      id: `cons${Date.now()}`,
      patientId: "patient1",
      doctorId: selectedDoctor,
      date: new Date(date),
      time,
      notes: "",
      status: "scheduled" as const,
      symptoms,
    }

    addConsultation(consultation)

    const notification = {
      id: `notif${Date.now()}`,
      userId: "patient1",
      title: "Consultation Booked",
      message: `Your consultation with ${mockDoctors.find((d) => d.id === selectedDoctor)?.name} is scheduled for ${date} at ${time}`,
      type: "appointment" as const,
      read: false,
      createdAt: new Date(),
    }

    addNotification(notification)

    setSuccessMessage("Consultation booked successfully!")
    setTimeout(() => setSuccessMessage(""), 3000)

    setSelectedDoctor("")
    setSymptoms("")
    setDate("")
    setTime("")
  }

  return (
    <Card className="border-primary/20 shadow-lg hover:shadow-xl transition-all animate-in overflow-hidden">
      <div className="h-1 bg-gradient-to-r from-primary to-secondary" />
      <CardHeader className="bg-gradient-to-r from-primary/5 to-secondary/5">
        <CardTitle className="flex items-center gap-2 text-xl">
          <span className="text-2xl">👨‍⚕️</span>Book a Consultation
        </CardTitle>
        <CardDescription>Schedule your doctor appointment</CardDescription>
      </CardHeader>
      <CardContent className="pt-6">
        <form onSubmit={handleBooking} className="space-y-4">
          {successMessage && (
            <Alert className="bg-gradient-to-r from-green-50 to-green-50/50 border-green-200 dark:from-green-950/30 dark:to-green-950/20 dark:border-green-800/30 animate-slide-down">
              <AlertDescription className="text-green-800 dark:text-green-200 font-medium">
                ✓ {successMessage}
              </AlertDescription>
            </Alert>
          )}

          <div className="space-y-2">
            <label className="text-sm font-semibold">Select Doctor</label>
            <select
              value={selectedDoctor}
              onChange={(e) => setSelectedDoctor(e.target.value)}
              className="w-full px-4 py-2 border border-primary/30 rounded-lg bg-background text-foreground focus:border-primary focus:ring-primary/30 transition-all"
              required
            >
              <option value="">Choose a doctor...</option>
              {mockDoctors.map((doctor) => (
                <option key={doctor.id} value={doctor.id}>
                  {doctor.name} - {doctor.specialization} (₹{doctor.consultationFee})
                </option>
              ))}
            </select>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-semibold">Symptoms</label>
            <textarea
              placeholder="Describe your symptoms in detail..."
              value={symptoms}
              onChange={(e) => setSymptoms(e.target.value)}
              className="w-full px-4 py-2 border border-primary/30 rounded-lg bg-background text-foreground focus:border-primary focus:ring-primary/30 transition-all"
              rows={3}
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-semibold">Date</label>
              <Input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="border-primary/30 focus:border-primary focus:ring-primary/30"
                required
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-semibold">Time</label>
              <Input
                type="time"
                value={time}
                onChange={(e) => setTime(e.target.value)}
                className="border-primary/30 focus:border-primary focus:ring-primary/30"
                required
              />
            </div>
          </div>

          <Button className="w-full bg-gradient-to-r from-primary to-secondary hover:shadow-lg text-primary-foreground font-semibold py-5 rounded-lg transition-all duration-300">
            Book Consultation
          </Button>
        </form>
      </CardContent>
    </Card>
  )
}
