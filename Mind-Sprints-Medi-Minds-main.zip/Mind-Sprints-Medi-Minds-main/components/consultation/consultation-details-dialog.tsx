"use client"

import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import type { Consultation } from "@/lib/types"
import { Calendar, Clock, User, FileText } from "lucide-react"

interface ConsultationDetailsDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  consultation: Consultation | null
}

export function ConsultationDetailsDialog({ open, onOpenChange, consultation }: ConsultationDetailsDialogProps) {
  if (!consultation) return null

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="text-2xl flex items-center gap-2">
            <span className="text-3xl">👨‍⚕️</span>
            Consultation Details
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-6 mt-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="flex items-start gap-3 p-4 bg-blue-50 dark:bg-blue-950/20 rounded-lg">
              <Calendar className="h-5 w-5 text-blue-600 dark:text-blue-400 mt-1" />
              <div>
                <p className="text-sm font-medium text-muted-foreground">Date</p>
                <p className="text-lg font-semibold">{consultation.date.toLocaleDateString()}</p>
              </div>
            </div>
            <div className="flex items-start gap-3 p-4 bg-purple-50 dark:bg-purple-950/20 rounded-lg">
              <Clock className="h-5 w-5 text-purple-600 dark:text-purple-400 mt-1" />
              <div>
                <p className="text-sm font-medium text-muted-foreground">Time</p>
                <p className="text-lg font-semibold">{consultation.time}</p>
              </div>
            </div>
          </div>

          <div className="p-4 bg-green-50 dark:bg-green-950/20 rounded-lg">
            <div className="flex items-start gap-3">
              <User className="h-5 w-5 text-green-600 dark:text-green-400 mt-1" />
              <div className="flex-1">
                <p className="text-sm font-medium text-muted-foreground">Doctor ID</p>
                <p className="text-lg font-semibold">{consultation.doctorId}</p>
              </div>
            </div>
          </div>

          <div className="p-4 bg-orange-50 dark:bg-orange-950/20 rounded-lg">
            <div className="flex items-start gap-3">
              <FileText className="h-5 w-5 text-orange-600 dark:text-orange-400 mt-1" />
              <div className="flex-1">
                <p className="text-sm font-medium text-muted-foreground mb-2">Symptoms</p>
                <p className="text-base">{consultation.symptoms}</p>
              </div>
            </div>
          </div>

          {consultation.notes && (
            <div className="p-4 bg-gray-50 dark:bg-gray-950/20 rounded-lg">
              <p className="text-sm font-medium text-muted-foreground mb-2">Doctor's Notes</p>
              <p className="text-base">{consultation.notes}</p>
            </div>
          )}

          <div className="flex items-center gap-2">
            <span className="text-sm font-medium">Status:</span>
            <span
              className={`px-3 py-1 rounded-full text-xs font-medium ${
                consultation.status === "scheduled"
                  ? "bg-blue-100 dark:bg-blue-950 text-blue-900 dark:text-blue-100"
                  : "bg-green-100 dark:bg-green-950 text-green-900 dark:text-green-100"
              }`}
            >
              {consultation.status}
            </span>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
