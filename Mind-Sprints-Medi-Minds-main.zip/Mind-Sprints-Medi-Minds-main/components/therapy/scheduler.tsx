"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { useAppStore } from "@/lib/store"
import { mockTherapists, mockRooms } from "@/lib/mock-data"

export function TherapyScheduler() {
  const { addTherapySession, addNotification } = useAppStore()
  const [selectedTherapist, setSelectedTherapist] = useState("")
  const [selectedRoom, setSelectedRoom] = useState("")
  const [date, setDate] = useState("")
  const [startTime, setStartTime] = useState("")
  const [endTime, setEndTime] = useState("")
  const [successMessage, setSuccessMessage] = useState("")

  const handleScheduling = (e: React.FormEvent) => {
    e.preventDefault()

    const therapySession = {
      id: `therapy${Date.now()}`,
      patientId: "patient1",
      therapistId: selectedTherapist,
      roomId: selectedRoom,
      date: new Date(date),
      startTime,
      endTime,
      status: "scheduled" as const,
      notes: "",
    }

    addTherapySession(therapySession)

    const therapist = mockTherapists.find((t) => t.id === selectedTherapist)
    const notification = {
      id: `notif${Date.now()}`,
      userId: "patient1",
      title: "Therapy Session Scheduled",
      message: `Your therapy session with ${therapist?.name} is scheduled for ${date} from ${startTime} to ${endTime}`,
      type: "therapy" as const,
      read: false,
      createdAt: new Date(),
    }

    addNotification(notification)

    setSuccessMessage("Therapy session scheduled successfully!")
    setTimeout(() => setSuccessMessage(""), 3000)

    setSelectedTherapist("")
    setSelectedRoom("")
    setDate("")
    setStartTime("")
    setEndTime("")
  }

  return (
    <Card className="border-primary/20 shadow-lg hover:shadow-xl transition-all animate-in overflow-hidden">
      <div className="h-1 bg-gradient-to-r from-green-500 to-emerald-500" />
      <CardHeader className="bg-gradient-to-r from-green-50/20 to-emerald-50/20 dark:from-green-950/20 dark:to-emerald-950/20">
        <CardTitle className="flex items-center gap-2 text-xl">
          <span className="text-2xl">🧘</span>Schedule Therapy Session
        </CardTitle>
        <CardDescription>Book your therapeutic appointment</CardDescription>
      </CardHeader>
      <CardContent className="pt-6">
        <form onSubmit={handleScheduling} className="space-y-4">
          {successMessage && (
            <Alert className="bg-gradient-to-r from-green-50 to-green-50/50 border-green-200 dark:from-green-950/30 dark:to-green-950/20 dark:border-green-800/30 animate-slide-down">
              <AlertDescription className="text-green-800 dark:text-green-200 font-medium">
                ✓ {successMessage}
              </AlertDescription>
            </Alert>
          )}

          <div className="space-y-2">
            <label className="text-sm font-semibold">Select Therapist</label>
            <select
              value={selectedTherapist}
              onChange={(e) => setSelectedTherapist(e.target.value)}
              className="w-full px-4 py-2 border border-primary/30 rounded-lg bg-background text-foreground focus:border-primary focus:ring-primary/30 transition-all"
              required
            >
              <option value="">Choose a therapist...</option>
              {mockTherapists.map((therapist) => (
                <option key={therapist.id} value={therapist.id}>
                  {therapist.name} - {therapist.specialization}
                </option>
              ))}
            </select>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-semibold">Select Room</label>
            <select
              value={selectedRoom}
              onChange={(e) => setSelectedRoom(e.target.value)}
              className="w-full px-4 py-2 border border-primary/30 rounded-lg bg-background text-foreground focus:border-primary focus:ring-primary/30 transition-all"
              required
            >
              <option value="">Choose a room...</option>
              {mockRooms.map((room) => (
                <option key={room.id} value={room.id}>
                  {room.name} - {room.amenities.join(", ")}
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-semibold">Date</label>
              <input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full px-4 py-2 border border-primary/30 rounded-lg bg-background text-foreground focus:border-primary focus:ring-primary/30 transition-all"
                required
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-semibold">Time Slot</label>
              <select
                value={`${startTime}-${endTime}`}
                onChange={(e) => {
                  const [start, end] = e.target.value.split("-")
                  setStartTime(start)
                  setEndTime(end)
                }}
                className="w-full px-4 py-2 border border-primary/30 rounded-lg bg-background text-foreground focus:border-primary focus:ring-primary/30 transition-all"
                required
              >
                <option value="">Select time...</option>
                <option value="09:00-10:00">9:00 AM - 10:00 AM</option>
                <option value="10:00-11:00">10:00 AM - 11:00 AM</option>
                <option value="14:00-15:00">2:00 PM - 3:00 PM</option>
                <option value="15:00-16:00">3:00 PM - 4:00 PM</option>
              </select>
            </div>
          </div>

          <Button className="w-full bg-gradient-to-r from-green-500 to-emerald-500 hover:shadow-lg text-white font-semibold py-5 rounded-lg transition-all duration-300">
            Schedule Session
          </Button>
        </form>
      </CardContent>
    </Card>
  )
}
