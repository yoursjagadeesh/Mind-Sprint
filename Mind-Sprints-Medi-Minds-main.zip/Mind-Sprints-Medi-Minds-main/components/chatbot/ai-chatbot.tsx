"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card } from "@/components/ui/card"
import { useAppStore } from "@/lib/store"
import { MessageCircle, Send, X } from "lucide-react"

const BOT_RESPONSES: { [key: string]: string } = {
  "how to book":
    'To book a consultation: 1) Click "Book a Consultation" 2) Select a doctor from the list 3) Describe your symptoms 4) Choose date and time 5) Click "Book Consultation". You\'ll receive a notification once confirmed.',
  prescription:
    'Your prescriptions are available in the "Recent Prescriptions" section on your dashboard. You can view medication details, dosage, and duration. Digital prescriptions are encrypted and can be shared with pharmacies directly.',
  therapy:
    'To schedule therapy: 1) Go to "Schedule Therapy Session" 2) Select your preferred therapist 3) Choose a therapy room 4) Pick a date and time slot 5) Confirm booking. Our system ensures no room conflicts.',
  appointment:
    "View all appointments in your dashboard. You get notifications 24 hours and 1 hour before each appointment. Click on any appointment to see details, reschedule, or cancel.",
  cancel:
    "To cancel an appointment, go to your appointments list and click the cancel button. You'll be refunded the consultation fee.",
  doctor:
    "We have experienced doctors across Cardiology, Neurology, Dermatology, Psychiatry, and more. All doctors are verified medical professionals with years of experience.",
  payment:
    "We accept all major payment methods including UPI, cards, and digital wallets. Payments are secure and encrypted. You can see the consultation fee before booking.",
  emergency:
    "For medical emergencies, please contact your nearest hospital or emergency services. Our platform is for non-emergency consultations.",
  "mental health":
    "We offer therapy sessions for anxiety, depression, stress management, and counseling. Our therapists are certified professionals. Book a session in the therapy section.",
  insurance:
    "We're working on insurance integration. Currently, you pay out-of-pocket, but we provide detailed receipts for insurance claims.",
  report:
    "Medical reports and test results can be uploaded directly to your profile. You can share them with doctors during consultations for better diagnosis.",
  follow:
    "Follow-up consultations are available after your initial consultation. Your doctor can recommend follow-ups based on your condition.",
  default:
    "I can help you with booking consultations, scheduling therapy, viewing prescriptions, managing appointments, payments, medical reports, and more. What would you like help with?",
}

export function AIChatbot() {
  const { chatMessages, addChatMessage } = useAppStore()
  const [input, setInput] = useState("")
  const [isOpen, setIsOpen] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    scrollToBottom()
  }, [chatMessages])

  const findBotResponse = (userMessage: string): string => {
    const lowerMessage = userMessage.toLowerCase()
    for (const [key, value] of Object.entries(BOT_RESPONSES)) {
      if (lowerMessage.includes(key)) {
        return value
      }
    }
    return BOT_RESPONSES["default"]
  }

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault()
    if (!input.trim()) return

    setIsLoading(true)

    addChatMessage({
      id: `msg${Date.now()}user`,
      sender: "user",
      message: input,
      timestamp: new Date(),
    })

    const botResponse = findBotResponse(input)
    setTimeout(() => {
      addChatMessage({
        id: `msg${Date.now()}bot`,
        sender: "bot",
        message: botResponse,
        timestamp: new Date(),
      })
      setIsLoading(false)
    }, 800)

    setInput("")
  }

  return (
    <>
      {/* Chatbot Window */}
      {isOpen && (
        <Card className="fixed bottom-24 right-6 w-96 max-h-[600px] shadow-2xl border-primary/20 flex flex-col animate-scale-in z-50 overflow-hidden">
          {/* Header */}
          <div className="bg-gradient-to-r from-primary to-secondary text-primary-foreground p-4 rounded-t-lg flex justify-between items-center">
            <div className="flex items-center gap-2">
              <MessageCircle className="w-5 h-5" />
              <h3 className="font-bold">Smart Healthcare Assistant</h3>
            </div>
            <button onClick={() => setIsOpen(false)} className="hover:bg-white/20 p-1 rounded-lg transition-colors">
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Messages Area */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-gradient-to-b from-background to-primary/2">
            {chatMessages.length === 0 && (
              <div className="text-center text-muted-foreground text-sm py-8 space-y-2">
                <div className="text-3xl mb-3">👋</div>
                <p className="font-semibold">Hello! I'm your healthcare assistant.</p>
                <p className="text-xs">Ask me about consultations, therapy, prescriptions, and more!</p>
              </div>
            )}
            {chatMessages.map((msg, index) => (
              <div
                key={msg.id}
                className={`flex ${msg.sender === "user" ? "justify-end" : "justify-start"} animate-slide-in-left`}
                style={{ animationDelay: `${index * 50}ms` }}
              >
                <div
                  className={`max-w-xs px-4 py-3 rounded-2xl text-sm leading-relaxed ${
                    msg.sender === "user"
                      ? "bg-gradient-to-r from-primary to-secondary text-primary-foreground rounded-br-none shadow-md"
                      : "bg-muted text-foreground rounded-bl-none shadow-sm border border-border/50"
                  }`}
                >
                  {msg.message}
                </div>
              </div>
            ))}
            {isLoading && (
              <div className="flex justify-start">
                <div className="bg-muted text-foreground rounded-2xl px-4 py-3 space-y-2">
                  <div className="flex gap-1">
                    <div className="w-2 h-2 bg-primary rounded-full animate-bounce" />
                    <div
                      className="w-2 h-2 bg-primary rounded-full animate-bounce"
                      style={{ animationDelay: "100ms" }}
                    />
                    <div
                      className="w-2 h-2 bg-primary rounded-full animate-bounce"
                      style={{ animationDelay: "200ms" }}
                    />
                  </div>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Input Area */}
          <form onSubmit={handleSendMessage} className="border-t border-border p-3 flex gap-2 bg-card">
            <Input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Type your question..."
              className="text-sm border-primary/30 focus:border-primary"
              disabled={isLoading}
            />
            <Button
              type="submit"
              size="sm"
              className="bg-gradient-to-r from-primary to-secondary hover:shadow-lg text-primary-foreground"
              disabled={isLoading}
            >
              <Send className="w-4 h-4" />
            </Button>
          </form>
        </Card>
      )}

      {/* Floating Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="fixed bottom-6 right-6 w-16 h-16 bg-gradient-to-br from-primary to-secondary hover:shadow-2xl text-primary-foreground rounded-full shadow-lg flex items-center justify-center font-bold text-2xl animate-bounce-mild z-40 hover:scale-110 transition-all duration-300"
        title="Chat with AI Assistant"
      >
        💬
      </button>
    </>
  )
}
