"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import {
  LayoutDashboard,
  User,
  MessageSquare,
  FileText,
  Activity,
  AlertTriangle,
  ChevronLeft,
  ChevronRight,
  Users,
  HelpCircle,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { useState } from "react"
import { useAppStore } from "@/lib/store"

export function Sidebar() {
  const pathname = usePathname()
  const [isCollapsed, setIsCollapsed] = useState(false)
  const { currentUser } = useAppStore()

  const getMenuItems = () => {
    const role = currentUser?.role

    const baseItems = [
      {
        icon: LayoutDashboard,
        label: "Dashboard",
        href:
          role === "patient"
            ? "/patient/dashboard"
            : role === "doctor"
              ? "/doctor/dashboard"
              : role === "therapist"
                ? "/therapist/dashboard"
                : role === "admin"
                  ? "/admin/dashboard"
                  : "/receptionist/dashboard",
      },
      { icon: User, label: "Profile", href: "/profile" },
      { icon: MessageSquare, label: "Feedback", href: "/feedback" },
      { icon: FileText, label: "Reports", href: "/reports" },
      { icon: HelpCircle, label: "Help", href: "/help" }, // Added Help menu item
    ]

    // Add analytics items for doctors and admins
    if (role === "doctor" || role === "admin") {
      baseItems.push(
        { icon: Activity, label: "Health Pattern Analyzer", href: "/analytics/health-patterns" },
        { icon: AlertTriangle, label: "Community Risk Predictor", href: "/analytics/community-risks" },
      )
    }

    // Add admin-specific items
    if (role === "admin") {
      baseItems.push({ icon: Users, label: "User Management", href: "/admin/dashboard" })
    }

    return baseItems
  }

  const menuItems = getMenuItems()

  return (
    <aside
      className={`fixed left-0 top-0 h-screen bg-card border-r border-border transition-all duration-300 z-50 ${
        isCollapsed ? "w-16" : "w-64"
      }`}
    >
      <div className="flex flex-col h-full">
        {/* Header */}
        <div className="p-4 border-b border-border flex items-center justify-between">
          {!isCollapsed && (
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-gradient-to-br from-primary to-secondary rounded-lg flex items-center justify-center">
                <span className="text-lg">⚕️</span>
              </div>
              <span className="font-bold text-lg">Smart Health</span>
            </div>
          )}
          <Button variant="ghost" size="icon" onClick={() => setIsCollapsed(!isCollapsed)} className="ml-auto">
            {isCollapsed ? <ChevronRight className="h-4 w-4" /> : <ChevronLeft className="h-4 w-4" />}
          </Button>
        </div>

        {/* Menu Items */}
        <nav className="flex-1 p-2 space-y-1 overflow-y-auto">
          {menuItems.map((item) => {
            const Icon = item.icon
            const isActive = pathname === item.href

            return (
              <Link key={item.href} href={item.href}>
                <div
                  className={`flex items-center gap-3 px-3 py-2 rounded-lg transition-all hover:bg-accent ${
                    isActive ? "bg-primary text-primary-foreground" : ""
                  } ${isCollapsed ? "justify-center" : ""}`}
                >
                  <Icon className="h-5 w-5 flex-shrink-0" />
                  {!isCollapsed && <span className="text-sm font-medium">{item.label}</span>}
                </div>
              </Link>
            )
          })}
        </nav>
      </div>
    </aside>
  )
}
