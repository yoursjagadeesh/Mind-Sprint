"use client"

import { useAppStore } from "@/lib/store"
import type { ReactNode } from "react"
import { Alert, AlertDescription } from "@/components/ui/alert"

interface RoleBasedAccessProps {
  allowedRoles: string[]
  children: ReactNode
  fallback?: ReactNode
}

export function RoleBasedAccess({ allowedRoles, children, fallback }: RoleBasedAccessProps) {
  const { currentUser } = useAppStore()

  if (!currentUser || !allowedRoles.includes(currentUser.role)) {
    return (
      fallback || (
        <Alert variant="destructive">
          <AlertDescription>You do not have permission to access this resource.</AlertDescription>
        </Alert>
      )
    )
  }

  return <>{children}</>
}
