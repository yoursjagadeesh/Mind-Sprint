"use client"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { useAppStore } from "@/lib/store"

export function NotificationCenter() {
  const { notifications, markNotificationAsRead, currentUser } = useAppStore()
  const [isOpen, setIsOpen] = useState(false)

  // Filter notifications for current user only
  const userNotifications = notifications.filter((n) => n.userId === currentUser?.id)
  const unreadCount = userNotifications.filter((n) => !n.read).length

  return (
    <>
      {isOpen && (
        <Card className="fixed top-20 right-6 w-96 max-h-96 overflow-y-auto shadow-2xl border-primary/20 z-50 animate-slide-down">
          <div className="p-4 border-b border-border sticky top-0 bg-background">
            <h3 className="font-semibold">Notifications</h3>
          </div>

          <div className="divide-y divide-border">
            {userNotifications.length === 0 ? (
              <div className="p-4 text-center text-muted-foreground text-sm">No notifications</div>
            ) : (
              userNotifications.map((notif) => (
                <div
                  key={notif.id}
                  className={`p-4 hover:bg-muted/50 transition-colors cursor-pointer ${
                    !notif.read ? "bg-primary/5" : ""
                  }`}
                  onClick={() => markNotificationAsRead(notif.id)}
                >
                  <div className="flex justify-between items-start mb-1">
                    <h4 className="font-medium text-sm">{notif.title}</h4>
                    {!notif.read && <div className="w-2 h-2 bg-primary rounded-full mt-1"></div>}
                  </div>
                  <p className="text-xs text-muted-foreground">{notif.message}</p>
                  <p className="text-xs text-muted-foreground mt-1">{new Date(notif.createdAt).toLocaleTimeString()}</p>
                </div>
              ))
            )}
          </div>
        </Card>
      )}

      <button onClick={() => setIsOpen(!isOpen)} className="relative p-2 hover:bg-muted rounded-lg transition-colors">
        🔔
        {unreadCount > 0 && (
          <span className="absolute top-0 right-0 w-5 h-5 bg-destructive text-white text-xs rounded-full flex items-center justify-center font-bold">
            {unreadCount}
          </span>
        )}
      </button>
    </>
  )
}
