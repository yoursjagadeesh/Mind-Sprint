"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { useAppStore } from "@/lib/store"

export function PatientRegistrationForm() {
  const { currentUser, addNotification } = useAppStore()
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(false)
  const [success, setSuccess] = useState(false)
  const [error, setError] = useState("")
  const [formData, setFormData] = useState({
    name: currentUser?.name || "",
    dateOfBirth: "",
    gender: "",
    phone: "",
    address: "",
    medicalHistory: "",
    allergies: "",
  })

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    setIsLoading(true)

    try {
      // Validate required fields
      if (!formData.name || !formData.dateOfBirth || !formData.gender || !formData.phone) {
        setError("Please fill in all required fields")
        setIsLoading(false)
        return
      }

      // Create patient profile
      const newPatient = {
        id: `patient_${Date.now()}`,
        userId: currentUser?.id || `user_${Date.now()}`,
        email: currentUser?.email || "",
        name: formData.name,
        dateOfBirth: formData.dateOfBirth,
        gender: formData.gender,
        phone: formData.phone,
        address: formData.address,
        medicalHistory: formData.medicalHistory,
        allergies: formData.allergies,
        createdAt: new Date(),
      }

      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1000))

      // Show success notification
      addNotification({
        id: `notif_${Date.now()}`,
        userId: currentUser?.id || "",
        type: "success",
        title: "Registration Complete",
        message: "Your patient profile has been created successfully!",
        read: false,
        createdAt: new Date(),
      })

      setSuccess(true)

      // Redirect to dashboard after 1.5 seconds
      setTimeout(() => {
        router.push("/patient/dashboard")
      }, 1500)
    } catch (err) {
      setError("Registration failed. Please try again.")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Card className="border-primary/20 animate-in">
      <CardHeader>
        <CardTitle>Patient Registration</CardTitle>
        <CardDescription>Complete your medical profile</CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          {error && (
            <Alert variant="destructive" className="animate-slide-down">
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          {success && (
            <Alert className="bg-green-50 dark:bg-green-950/30 border-green-200 dark:border-green-800 animate-slide-down">
              <AlertDescription className="text-green-800 dark:text-green-200">
                Registration successful! Redirecting to your dashboard...
              </AlertDescription>
            </Alert>
          )}

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Full Name *</label>
              <Input
                name="name"
                placeholder="John Doe"
                value={formData.name}
                onChange={handleChange}
                disabled={isLoading}
                required
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Date of Birth *</label>
              <Input
                name="dateOfBirth"
                type="date"
                value={formData.dateOfBirth}
                onChange={handleChange}
                disabled={isLoading}
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Gender *</label>
              <select
                name="gender"
                value={formData.gender}
                onChange={handleChange}
                disabled={isLoading}
                required
                className="w-full px-3 py-2 border border-input rounded-lg bg-background text-foreground"
              >
                <option value="">Select Gender</option>
                <option value="male">Male</option>
                <option value="female">Female</option>
                <option value="other">Other</option>
              </select>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Phone *</label>
              <Input
                name="phone"
                placeholder="+91 98765 43210"
                value={formData.phone}
                onChange={handleChange}
                disabled={isLoading}
                required
              />
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium">Address</label>
            <Input
              name="address"
              placeholder="Your address"
              value={formData.address}
              onChange={handleChange}
              disabled={isLoading}
            />
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium">Medical History</label>
            <textarea
              name="medicalHistory"
              placeholder="Any previous medical conditions..."
              value={formData.medicalHistory}
              onChange={handleChange}
              disabled={isLoading}
              className="w-full px-3 py-2 border border-input rounded-lg bg-background text-foreground"
              rows={3}
            />
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium">Allergies</label>
            <Input
              name="allergies"
              placeholder="List any allergies (comma-separated)"
              value={formData.allergies}
              onChange={handleChange}
              disabled={isLoading}
            />
          </div>

          <Button
            type="submit"
            className="w-full bg-primary hover:bg-primary/90 text-primary-foreground"
            disabled={isLoading}
          >
            {isLoading ? "Registering..." : "Complete Registration"}
          </Button>
        </form>
      </CardContent>
    </Card>
  )
}
